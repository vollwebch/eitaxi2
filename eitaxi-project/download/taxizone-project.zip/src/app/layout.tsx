import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "TaxiZone - Encuentra tu taxi en Suiza",
  description: "La plataforma líder de taxis en Suiza. Encuentra taxistas verificados, reserva traslados al aeropuerto, viajes de larga distancia y más. Conecta directamente con conductores profesionales.",
  keywords: ["taxi", "Suiza", "Zürich", "Ginebra", "Bern", "traslado", "aeropuerto", "taxista"],
  authors: [{ name: "TaxiZone" }],
  icons: {
    icon: "data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🚕</text></svg>",
  },
  openGraph: {
    title: "TaxiZone - Tu taxi en Suiza",
    description: "Encuentra tu taxi ideal en Suiza. Taxistas verificados, servicio 24/7.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es" suppressHydrationWarning className="dark">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
