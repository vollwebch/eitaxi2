"use client";

import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Car,
  User,
  Phone,
  MessageCircle,
  MapPin,
  Clock,
  Check,
  ArrowLeft,
  Star,
  Sparkles,
  Loader2,
  Building2,
  Route,
  Plane,
  Shield,
  Upload,
  X,
  Globe,
  Calendar,
  Users,
  Wand2,
  FileText,
  Eye,
  DollarSign,
  Plus,
  Trash2,
  Instagram,
  Facebook,
  Link as LinkIcon,
  Mail,
  Lock,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";

// Types
interface City {
  id: string;
  name: string;
  slug: string;
}

interface Canton {
  id: string;
  name: string;
  code: string;
  slug: string;
  cities: City[];
}

interface DriverRoute {
  origin: string;
  destination: string;
  price?: number;
}

interface Schedule {
  dayOfWeek: number;
  startTime: string;
  endTime: string;
  isActive: boolean;
}

// Vehicle types - multiple selection allowed
const vehicleTypes = [
  { id: "taxi", label: "Taxi", icon: "🚕", description: "Vehículo estándar" },
  { id: "limousine", label: "Limusina", icon: "🚗", description: "Servicio premium" },
  { id: "van", label: "Van / Minibus", icon: "🚐", description: "Grupos grandes" },
  { id: "premium", label: "Premium / Ejecutivo", icon: "✨", description: "Alta gama" },
];

// Service options
const serviceOptions = [
  { id: "airport", label: "Traslados al aeropuerto", icon: Plane },
  { id: "city", label: "Viajes dentro de la ciudad", icon: Building2 },
  { id: "long_distance", label: "Larga distancia", icon: Route },
  { id: "limousine", label: "Servicio de limusina", icon: Car },
  { id: "corporate", label: "Servicio corporativo", icon: Shield },
  { id: "events", label: "Eventos y celebraciones", icon: Star },
  { id: "delivery", label: "Entregas y mensajería", icon: Route },
  { id: "night", label: "Servicio nocturno", icon: Clock },
];

// Language options
const languageOptions = [
  { id: "de", label: "Alemán", flag: "🇩🇪" },
  { id: "en", label: "Inglés", flag: "🇬🇧" },
  { id: "fr", label: "Francés", flag: "🇫🇷" },
  { id: "it", label: "Italiano", flag: "🇮🇹" },
  { id: "es", label: "Español", flag: "🇪🇸" },
  { id: "pt", label: "Portugués", flag: "🇵🇹" },
  { id: "ru", label: "Ruso", flag: "🇷🇺" },
  { id: "zh", label: "Chino", flag: "🇨🇳" },
];

// Popular zones
const popularZones = [
  "Centro de la ciudad",
  "Aeropuerto",
  "Estación de tren",
  "Zona empresarial",
  "Área metropolitana",
  "Zona turística",
];

// Popular routes suggestions
const popularRoutes = [
  { origin: "Zürich", destination: "Aeropuerto Zürich" },
  { origin: "Ginebra", destination: "Aeropuerto Ginebra" },
  { origin: "Zürich", destination: "Ginebra" },
  { origin: "Basel", destination: "Aeropuerto Basel" },
  { origin: "Bern", destination: "Zürich" },
];

// Days of week for schedule
const daysOfWeek = [
  { value: 1, label: "Lunes" },
  { value: 2, label: "Martes" },
  { value: 3, label: "Miércoles" },
  { value: 4, label: "Jueves" },
  { value: 5, label: "Viernes" },
  { value: 6, label: "Sábado" },
  { value: 0, label: "Domingo" },
];

// Step config - now 8 steps
const steps = [
  { id: 1, title: "Datos básicos", description: "Tu información" },
  { id: 2, title: "Ubicación", description: "Dónde operas" },
  { id: 3, title: "Vehículo", description: "Tu vehículo" },
  { id: 4, title: "Servicios", description: "Qué ofreces" },
  { id: 5, title: "Rutas y precios", description: "Tus tarifas" },
  { id: 6, title: "Horarios", description: "Disponibilidad" },
  { id: 7, title: "Descripción", description: "Sobre ti" },
  { id: 8, title: "Vista previa", description: "Confirmar" },
];

export default function RegistrarsePage() {
  // Form state
  const [currentStep, setCurrentStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isGeneratingAI, setIsGeneratingAI] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const [profileUrl, setProfileUrl] = useState<string | null>(null);
  const [driverId, setDriverId] = useState<string | null>(null);
  
  // Data state
  const [cantons, setCantons] = useState<Canton[]>([]);
  const [selectedCanton, setSelectedCanton] = useState<string>("");
  const [availableCities, setAvailableCities] = useState<City[]>([]);
  
  // Image state
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Form data with new fields
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    whatsapp: "",
    email: "",
    password: "",
    confirmPassword: "",
    cityId: "",
    cantonId: "",
    address: "",
    experience: 1,
    description: "",
    originalDescription: "",
    services: [] as string[],
    languages: [] as string[],
    serviceZones: [] as string[],
    isAvailable24h: true,
    vehicleTypes: [] as string[],
    vehicleBrand: "",
    vehicleModel: "",
    vehicleYear: undefined as number | undefined,
    vehicleColor: "",
    passengerCapacity: undefined as number | undefined,
    // New price fields
    basePrice: undefined as number | undefined,
    pricePerKm: undefined as number | undefined,
    hourlyRate: undefined as number | undefined,
    // Social media
    website: "",
    instagram: "",
    facebook: "",
    subscription: "free",
  });

  // Routes state
  const [routes, setRoutes] = useState<DriverRoute[]>([]);
  const [newRoute, setNewRoute] = useState<DriverRoute>({ origin: "", destination: "", price: undefined });

  // Schedule state
  const [schedules, setSchedules] = useState<Schedule[]>(
    daysOfWeek.map(day => ({
      dayOfWeek: day.value,
      startTime: "09:00",
      endTime: "18:00",
      isActive: day.value >= 1 && day.value <= 5, // Mon-Fri active by default
    }))
  );

  // Fetch cantons on mount
  useEffect(() => {
    fetch("/api/cantons")
      .then((res) => res.json())
      .then((data) => {
        if (data.success) {
          setCantons(data.data);
        }
      })
      .catch(console.error);
  }, []);

  // Update cities when canton changes
  useEffect(() => {
    const canton = cantons.find((c) => c.id === selectedCanton);
    if (canton) {
      setAvailableCities(canton.cities);
      setFormData((prev) => ({ ...prev, cantonId: canton.id, cityId: "" }));
    }
  }, [selectedCanton, cantons]);

  // Handle image upload
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        setError("La imagen no puede superar los 5MB");
        return;
      }
      setImageFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const removeImage = () => {
    setImageFile(null);
    setImagePreview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  // Handle service toggle
  const toggleService = (serviceId: string) => {
    setFormData((prev) => ({
      ...prev,
      services: prev.services.includes(serviceId)
        ? prev.services.filter((s) => s !== serviceId)
        : [...prev.services, serviceId],
    }));
  };

  // Handle vehicle type toggle (multiple selection)
  const toggleVehicleType = (typeId: string) => {
    setFormData((prev) => ({
      ...prev,
      vehicleTypes: prev.vehicleTypes.includes(typeId)
        ? prev.vehicleTypes.filter((t) => t !== typeId)
        : [...prev.vehicleTypes, typeId],
    }));
  };

  // Handle language toggle
  const toggleLanguage = (langId: string) => {
    setFormData((prev) => ({
      ...prev,
      languages: prev.languages.includes(langId)
        ? prev.languages.filter((l) => l !== langId)
        : [...prev.languages, langId],
    }));
  };

  // Handle zone toggle
  const toggleZone = (zone: string) => {
    setFormData((prev) => ({
      ...prev,
      serviceZones: prev.serviceZones.includes(zone)
        ? prev.serviceZones.filter((z) => z !== zone)
        : [...prev.serviceZones, zone],
    }));
  };

  // Add route
  const addRoute = () => {
    if (newRoute.origin && newRoute.destination) {
      setRoutes([...routes, newRoute]);
      setNewRoute({ origin: "", destination: "", price: undefined });
    }
  };

  // Remove route
  const removeRoute = (index: number) => {
    setRoutes(routes.filter((_, i) => i !== index));
  };

  // Toggle schedule
  const toggleSchedule = (dayOfWeek: number) => {
    setSchedules(schedules.map(s => 
      s.dayOfWeek === dayOfWeek ? { ...s, isActive: !s.isActive } : s
    ));
  };

  // Update schedule time
  const updateScheduleTime = (dayOfWeek: number, field: 'startTime' | 'endTime', value: string) => {
    setSchedules(schedules.map(s => 
      s.dayOfWeek === dayOfWeek ? { ...s, [field]: value } : s
    ));
  };

  // Generate AI description
  const generateAIDescription = async () => {
    if (!formData.name || formData.services.length === 0) {
      setError("Por favor completa tu nombre y selecciona al menos un servicio");
      return;
    }

    setIsGeneratingAI(true);
    setError(null);

    try {
      const response = await fetch("/api/ai/generate-description", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: formData.name,
          services: formData.services,
          experience: formData.experience,
          vehicleTypes: formData.vehicleTypes,
          city: availableCities.find(c => c.id === formData.cityId)?.name || "",
          canton: cantons.find(c => c.id === formData.cantonId)?.name || "",
          languages: formData.languages,
        }),
      });

      const data = await response.json();

      if (data.success) {
        setFormData((prev) => ({
          ...prev,
          originalDescription: prev.description,
          description: data.description,
        }));
      } else {
        setError(data.error || "Error al generar descripción");
      }
    } catch (err) {
      setError("Error de conexión. Intenta de nuevo.");
    } finally {
      setIsGeneratingAI(false);
    }
  };

  // Validate current step
  const validateStep = (): boolean => {
    switch (currentStep) {
      case 1:
        return !!formData.name && !!formData.phone && !!formData.email && !!formData.password && formData.password.length >= 6;
      case 2:
        return !!formData.cantonId && !!formData.cityId;
      case 3:
        return formData.vehicleTypes.length > 0;
      case 4:
        return formData.services.length > 0;
      case 5:
        return true; // Routes and prices are optional
      case 6:
        return true; // Schedules have defaults
      case 7:
        return true; // Description is optional
      case 8:
        return true;
      default:
        return false;
    }
  };

  // Handle next step
  const nextStep = () => {
    if (validateStep()) {
      setError(null);
      setCurrentStep((prev) => Math.min(prev + 1, 8));
    } else {
      setError("Por favor completa todos los campos obligatorios");
    }
  };

  // Handle previous step
  const prevStep = () => {
    setCurrentStep((prev) => Math.max(prev - 1, 1));
    setError(null);
  };

  // Handle form submission
  const handleSubmit = async () => {
    if (!validateStep()) {
      setError("Por favor completa todos los campos");
      return;
    }

    // Validate password match
    if (formData.password !== formData.confirmPassword) {
      setError("Las contraseñas no coinciden");
      return;
    }

    setIsSubmitting(true);
    setError(null);

    try {
      // Upload image first if exists
      let imageUrl = null;
      if (imageFile) {
        const formDataImg = new FormData();
        formDataImg.append("file", imageFile);
        
        const uploadRes = await fetch("/api/upload", {
          method: "POST",
          body: formDataImg,
        });
        const uploadData = await uploadRes.json();
        if (uploadData.success) {
          imageUrl = uploadData.url;
        }
      }

      const response = await fetch("/api/drivers", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...formData,
          vehicleType: formData.vehicleTypes[0] || "taxi", // Primary vehicle type
          imageUrl,
          routes,
          schedules: formData.isAvailable24h ? null : schedules.filter(s => s.isActive),
        }),
      });

      const data = await response.json();

      if (data.success) {
        setSuccess(true);
        setProfileUrl(data.profileUrl);
        setDriverId(data.data.id);
      } else {
        setError(data.error || "Error al crear el perfil");
      }
    } catch (err) {
      setError("Error de conexión. Intenta de nuevo.");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Progress percentage
  const progressPercent = ((currentStep - 1) / (steps.length - 1)) * 100;

  // Get city name for preview
  const cityName = availableCities.find(c => c.id === formData.cityId)?.name || "";
  const cantonName = cantons.find(c => c.id === formData.cantonId)?.name || "";

  // Success screen
  if (success) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="max-w-md w-full text-center"
        >
          <div className="w-20 h-20 mx-auto mb-6 bg-green-500/20 rounded-full flex items-center justify-center">
            <Check className="w-10 h-10 text-green-500" />
          </div>
          <h1 className="text-2xl font-bold mb-2">¡Perfil creado!</h1>
          <p className="text-muted-foreground mb-6">
            Tu perfil profesional ha sido creado exitosamente y está activo.
          </p>
          
          {profileUrl && (
            <Card className="mb-6 border-yellow-400/30 bg-yellow-400/5">
              <CardContent className="p-4">
                <p className="text-sm text-muted-foreground mb-2">Tu URL pública:</p>
                <code className="block bg-background p-3 rounded text-yellow-400 text-lg font-mono break-all">
                  taxizone.ch{profileUrl}
                </code>
              </CardContent>
            </Card>
          )}

          {driverId && (
            <Card className="mb-6 border-blue-400/30 bg-blue-400/5">
              <CardContent className="p-4">
                <p className="text-sm text-muted-foreground mb-2">Tu panel de control:</p>
                <code className="block bg-background p-3 rounded text-blue-400 text-sm font-mono break-all">
                  taxizone.ch/dashboard/{driverId}
                </code>
                <p className="text-xs text-muted-foreground mt-2">
                  Guarda este enlace para editar tu perfil
                </p>
              </CardContent>
            </Card>
          )}

          <div className="flex flex-col gap-3">
            <Button 
              className="w-full bg-yellow-400 text-black hover:bg-yellow-500" 
              onClick={() => window.location.href = profileUrl || "/"}
            >
              <Eye className="mr-2 h-4 w-4" />
              Ver mi perfil
            </Button>
            {driverId && (
              <Button 
                variant="outline"
                className="w-full border-blue-400 text-blue-400 hover:bg-blue-400/10" 
                onClick={() => window.location.href = `/dashboard/${driverId}`}
              >
                Ir a mi panel
              </Button>
            )}
            <Button variant="outline" onClick={() => window.location.href = "/"}>
              Ir al inicio
            </Button>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background py-8 px-4">
      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 mb-4"
          >
            <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-gradient-to-br from-yellow-400 to-yellow-500">
              <Car className="h-7 w-7 text-black" />
            </div>
            <span className="text-2xl font-bold">
              <span className="text-yellow-400">Taxi</span>
              <span className="text-white">Zone</span>
            </span>
          </motion.div>
          <h1 className="text-3xl font-bold mb-2">Únete como conductor</h1>
          <p className="text-muted-foreground">
            Crea tu perfil profesional y conecta con miles de pasajeros en Suiza
          </p>
          <Badge variant="secondary" className="mt-2 bg-green-500/10 text-green-500 border-green-500/30">
            <Check className="mr-1 h-3 w-3" />
            Registro gratuito - Sin pagos
          </Badge>
        </div>

        {/* Progress bar */}
        <div className="mb-8">
          <Progress value={progressPercent} className="h-2 bg-muted" />
          <div className="flex justify-between mt-4 overflow-x-auto">
            {steps.map((step) => (
              <div
                key={step.id}
                className="flex flex-col items-center min-w-[60px]"
              >
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium transition-colors ${
                    currentStep >= step.id
                      ? "bg-yellow-400 text-black"
                      : "bg-muted text-muted-foreground"
                  }`}
                >
                  {currentStep > step.id ? (
                    <Check className="h-4 w-4" />
                  ) : (
                    step.id
                  )}
                </div>
                <span className="text-xs mt-1 hidden md:block text-muted-foreground whitespace-nowrap">
                  {step.title}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Error alert */}
        {error && (
          <Alert variant="destructive" className="mb-6">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {/* Form */}
        <Card className="border-border bg-card">
          <CardContent className="p-6">
            <AnimatePresence mode="wait">
              {/* Step 1: Basic Info */}
              {currentStep === 1 && (
                <motion.div
                  key="step1"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-6"
                >
                  <div>
                    <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                      <User className="h-5 w-5 text-yellow-400" />
                      Información básica
                    </h2>
                    
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="name">Nombre o nombre comercial *</Label>
                        <Input
                          id="name"
                          placeholder="Ej: Taxi Paco, Taxi Martínez, Luis Gómez..."
                          value={formData.name}
                          onChange={(e) =>
                            setFormData({ ...formData, name: e.target.value })
                          }
                          className="mt-1.5"
                        />
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="phone">Teléfono principal *</Label>
                          <div className="relative mt-1.5">
                            <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                            <Input
                              id="phone"
                              placeholder="+41 79 123 45 67"
                              value={formData.phone}
                              onChange={(e) =>
                                setFormData({ ...formData, phone: e.target.value })
                              }
                              className="pl-10"
                            />
                          </div>
                        </div>
                        <div>
                          <Label htmlFor="whatsapp">WhatsApp</Label>
                          <div className="relative mt-1.5">
                            <MessageCircle className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                            <Input
                              id="whatsapp"
                              placeholder="+41 79 123 45 67"
                              value={formData.whatsapp}
                              onChange={(e) =>
                                setFormData({ ...formData, whatsapp: e.target.value })
                              }
                              className="pl-10"
                            />
                          </div>
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="email">Email * (para acceder a tu panel)</Label>
                        <div className="relative mt-1.5">
                          <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                          <Input
                            id="email"
                            type="email"
                            placeholder="tu@email.com"
                            value={formData.email}
                            onChange={(e) =>
                              setFormData({ ...formData, email: e.target.value })
                            }
                            className="pl-10"
                          />
                        </div>
                        <p className="text-xs text-muted-foreground mt-1">
                          Usarás este email para iniciar sesión en tu panel
                        </p>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="password">Contraseña * (mín. 6 caracteres)</Label>
                          <div className="relative mt-1.5">
                            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                            <Input
                              id="password"
                              type="password"
                              placeholder="••••••••"
                              value={formData.password}
                              onChange={(e) =>
                                setFormData({ ...formData, password: e.target.value })
                              }
                              className="pl-10"
                            />
                          </div>
                        </div>
                        <div>
                          <Label htmlFor="confirmPassword">Confirmar contraseña *</Label>
                          <div className="relative mt-1.5">
                            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                            <Input
                              id="confirmPassword"
                              type="password"
                              placeholder="••••••••"
                              value={formData.confirmPassword}
                              onChange={(e) =>
                                setFormData({ ...formData, confirmPassword: e.target.value })
                              }
                              className="pl-10"
                            />
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="experience">Años de experiencia</Label>
                          <Input
                            id="experience"
                            type="number"
                            min={0}
                            max={50}
                            value={formData.experience}
                            onChange={(e) =>
                              setFormData({
                                ...formData,
                                experience: parseInt(e.target.value) || 0,
                              })
                            }
                            className="mt-1.5"
                          />
                        </div>
                      </div>

                      {/* Social Media */}
                      <Separator className="my-4" />
                      <h3 className="font-medium flex items-center gap-2">
                        <Globe className="h-4 w-4 text-yellow-400" />
                        Redes sociales (opcional)
                      </h3>
                      
                      <div className="space-y-3">
                        <div>
                          <Label htmlFor="website">Sitio web</Label>
                          <div className="relative mt-1.5">
                            <LinkIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                            <Input
                              id="website"
                              placeholder="https://tu-sitio.com"
                              value={formData.website}
                              onChange={(e) =>
                                setFormData({ ...formData, website: e.target.value })
                              }
                              className="pl-10"
                            />
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="instagram">Instagram</Label>
                            <div className="relative mt-1.5">
                              <Instagram className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                              <Input
                                id="instagram"
                                placeholder="@tu_usuario"
                                value={formData.instagram}
                                onChange={(e) =>
                                  setFormData({ ...formData, instagram: e.target.value })
                                }
                                className="pl-10"
                              />
                            </div>
                          </div>
                          <div>
                            <Label htmlFor="facebook">Facebook</Label>
                            <div className="relative mt-1.5">
                              <Facebook className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                              <Input
                                id="facebook"
                                placeholder="tu_pagina"
                                value={formData.facebook}
                                onChange={(e) =>
                                  setFormData({ ...formData, facebook: e.target.value })
                                }
                                className="pl-10"
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}

              {/* Step 2: Location */}
              {currentStep === 2 && (
                <motion.div
                  key="step2"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-6"
                >
                  <div>
                    <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                      <MapPin className="h-5 w-5 text-yellow-400" />
                      Ubicación y zona de servicio
                    </h2>

                    <div className="space-y-4">
                      <div>
                        <Label>Cantón *</Label>
                        <Select
                          value={selectedCanton}
                          onValueChange={setSelectedCanton}
                        >
                          <SelectTrigger className="mt-1.5">
                            <SelectValue placeholder="Selecciona tu cantón" />
                          </SelectTrigger>
                          <SelectContent>
                            {cantons.map((canton) => (
                              <SelectItem key={canton.id} value={canton.id}>
                                {canton.name} ({canton.code})
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <Label>Ciudad *</Label>
                        <Select
                          value={formData.cityId}
                          onValueChange={(value) =>
                            setFormData({ ...formData, cityId: value })
                          }
                          disabled={!selectedCanton}
                        >
                          <SelectTrigger className="mt-1.5">
                            <SelectValue placeholder="Selecciona tu ciudad" />
                          </SelectTrigger>
                          <SelectContent>
                            {availableCities.map((city) => (
                              <SelectItem key={city.id} value={city.id}>
                                {city.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <Label htmlFor="address">Dirección (opcional)</Label>
                        <Input
                          id="address"
                          placeholder="Calle y número"
                          value={formData.address}
                          onChange={(e) =>
                            setFormData({ ...formData, address: e.target.value })
                          }
                          className="mt-1.5"
                        />
                      </div>

                      <div>
                        <Label>Zonas de servicio</Label>
                        <p className="text-xs text-muted-foreground mb-2">
                          Selecciona las zonas donde operas
                        </p>
                        <div className="flex flex-wrap gap-2">
                          {popularZones.map((zone) => {
                            const isSelected = formData.serviceZones.includes(zone);
                            return (
                              <Badge
                                key={zone}
                                variant={isSelected ? "default" : "outline"}
                                className={`cursor-pointer transition-all ${
                                  isSelected
                                    ? "bg-yellow-400 text-black hover:bg-yellow-500"
                                    : "hover:bg-muted"
                                }`}
                                onClick={() => toggleZone(zone)}
                              >
                                {zone}
                                {isSelected && <Check className="ml-1 h-3 w-3" />}
                              </Badge>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}

              {/* Step 3: Vehicle - Multiple selection */}
              {currentStep === 3 && (
                <motion.div
                  key="step3"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-6"
                >
                  <div>
                    <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                      <Car className="h-5 w-5 text-yellow-400" />
                      Tipos de vehículo
                    </h2>

                    <div className="space-y-4">
                      {/* Vehicle Types - Multiple Selection */}
                      <div>
                        <Label>Tipos de vehículo que tienes *</Label>
                        <p className="text-xs text-muted-foreground mb-2">
                          Puedes seleccionar varios tipos si ofreces diferentes servicios
                        </p>
                        <div className="grid grid-cols-2 gap-3">
                          {vehicleTypes.map((type) => {
                            const isSelected = formData.vehicleTypes.includes(type.id);
                            return (
                              <button
                                key={type.id}
                                type="button"
                                onClick={() => toggleVehicleType(type.id)}
                                className={`p-4 rounded-lg border text-left transition-all ${
                                  isSelected
                                    ? "border-yellow-400 bg-yellow-400/10"
                                    : "border-border hover:border-yellow-400/50"
                                }`}
                              >
                                <div className="flex items-center justify-between">
                                  <div>
                                    <div className="text-2xl mb-1">{type.icon}</div>
                                    <div className="font-medium">{type.label}</div>
                                    <div className="text-xs text-muted-foreground">
                                      {type.description}
                                    </div>
                                  </div>
                                  {isSelected && (
                                    <Check className="h-5 w-5 text-yellow-400" />
                                  )}
                                </div>
                              </button>
                            );
                          })}
                        </div>
                      </div>

                      <Separator className="my-4" />

                      {/* Vehicle Details */}
                      <h3 className="font-medium">Detalles del vehículo principal</h3>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="vehicleBrand">Marca</Label>
                          <Input
                            id="vehicleBrand"
                            placeholder="Ej: Mercedes, BMW..."
                            value={formData.vehicleBrand}
                            onChange={(e) =>
                              setFormData({ ...formData, vehicleBrand: e.target.value })
                            }
                            className="mt-1.5"
                          />
                        </div>
                        <div>
                          <Label htmlFor="vehicleModel">Modelo</Label>
                          <Input
                            id="vehicleModel"
                            placeholder="Ej: E-Class..."
                            value={formData.vehicleModel}
                            onChange={(e) =>
                              setFormData({ ...formData, vehicleModel: e.target.value })
                            }
                            className="mt-1.5"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="vehicleYear">Año</Label>
                          <Input
                            id="vehicleYear"
                            type="number"
                            min={1990}
                            max={2026}
                            placeholder="Ej: 2022"
                            value={formData.vehicleYear || ""}
                            onChange={(e) =>
                              setFormData({
                                ...formData,
                                vehicleYear: parseInt(e.target.value) || undefined,
                              })
                            }
                            className="mt-1.5"
                          />
                        </div>
                        <div>
                          <Label htmlFor="vehicleColor">Color</Label>
                          <Input
                            id="vehicleColor"
                            placeholder="Ej: Negro"
                            value={formData.vehicleColor}
                            onChange={(e) =>
                              setFormData({ ...formData, vehicleColor: e.target.value })
                            }
                            className="mt-1.5"
                          />
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="passengerCapacity">Capacidad de pasajeros</Label>
                        <Input
                          id="passengerCapacity"
                          type="number"
                          min={1}
                          max={16}
                          placeholder="Ej: 4"
                          value={formData.passengerCapacity || ""}
                          onChange={(e) =>
                            setFormData({
                              ...formData,
                              passengerCapacity: parseInt(e.target.value) || undefined,
                            })
                          }
                          className="mt-1.5 w-32"
                        />
                      </div>

                      {/* Image Upload */}
                      <div>
                        <Label>Foto del vehículo o tu foto</Label>
                        <p className="text-xs text-muted-foreground mb-2">
                          Sube una foto profesional (máx. 5MB)
                        </p>
                        
                        {imagePreview ? (
                          <div className="relative inline-block">
                            <img
                              src={imagePreview}
                              alt="Preview"
                              className="w-48 h-48 object-cover rounded-lg border border-border"
                            />
                            <Button
                              type="button"
                              variant="destructive"
                              size="icon"
                              className="absolute -top-2 -right-2 h-6 w-6"
                              onClick={removeImage}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        ) : (
                          <div
                            onClick={() => fileInputRef.current?.click()}
                            className="w-48 h-48 border-2 border-dashed border-border rounded-lg flex flex-col items-center justify-center cursor-pointer hover:border-yellow-400 hover:bg-yellow-400/5 transition-all"
                          >
                            <Upload className="h-8 w-8 text-muted-foreground mb-2" />
                            <span className="text-sm text-muted-foreground">
                              Subir foto
                            </span>
                          </div>
                        )}
                        
                        <input
                          ref={fileInputRef}
                          type="file"
                          accept="image/*"
                          onChange={handleImageUpload}
                          className="hidden"
                        />
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}

              {/* Step 4: Services */}
              {currentStep === 4 && (
                <motion.div
                  key="step4"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-6"
                >
                  <div>
                    <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                      <Sparkles className="h-5 w-5 text-yellow-400" />
                      Servicios e idiomas
                    </h2>

                    <div className="space-y-6">
                      {/* Services */}
                      <div>
                        <Label>Servicios que ofreces *</Label>
                        <p className="text-xs text-muted-foreground mb-3">
                          Selecciona al menos un servicio
                        </p>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          {serviceOptions.map((service) => {
                            const Icon = service.icon;
                            const isSelected = formData.services.includes(service.id);
                            
                            return (
                              <button
                                key={service.id}
                                type="button"
                                onClick={() => toggleService(service.id)}
                                className={`p-4 rounded-lg border text-left transition-all ${
                                  isSelected
                                    ? "border-yellow-400 bg-yellow-400/10"
                                    : "border-border hover:border-yellow-400/50"
                                }`}
                              >
                                <div className="flex items-center gap-3">
                                  <Icon
                                    className={`h-5 w-5 ${
                                      isSelected ? "text-yellow-400" : "text-muted-foreground"
                                    }`}
                                  />
                                  <span className="font-medium">{service.label}</span>
                                  {isSelected && (
                                    <Check className="h-4 w-4 text-yellow-400 ml-auto" />
                                  )}
                                </div>
                              </button>
                            );
                          })}
                        </div>
                      </div>

                      {/* Languages */}
                      <div>
                        <Label className="flex items-center gap-2">
                          <Globe className="h-4 w-4" />
                          Idiomas que hablas
                        </Label>
                        <p className="text-xs text-muted-foreground mb-2">
                          Ayuda a los pasajeros a comunicarse contigo
                        </p>
                        <div className="flex flex-wrap gap-2">
                          {languageOptions.map((lang) => {
                            const isSelected = formData.languages.includes(lang.id);
                            return (
                              <Badge
                                key={lang.id}
                                variant={isSelected ? "default" : "outline"}
                                className={`cursor-pointer transition-all text-sm py-1.5 ${
                                  isSelected
                                    ? "bg-yellow-400 text-black hover:bg-yellow-500"
                                    : "hover:bg-muted"
                                }`}
                                onClick={() => toggleLanguage(lang.id)}
                              >
                                <span className="mr-1.5">{lang.flag}</span>
                                {lang.label}
                                {isSelected && <Check className="ml-1 h-3 w-3" />}
                              </Badge>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}

              {/* Step 5: Routes and Prices */}
              {currentStep === 5 && (
                <motion.div
                  key="step5"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-6"
                >
                  <div>
                    <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                      <DollarSign className="h-5 w-5 text-yellow-400" />
                      Rutas y precios
                    </h2>

                    <div className="space-y-6">
                      {/* Base prices */}
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                        <div>
                          <Label htmlFor="basePrice">Precio base (CHF)</Label>
                          <Input
                            id="basePrice"
                            type="number"
                            min={0}
                            placeholder="Ej: 5"
                            value={formData.basePrice || ""}
                            onChange={(e) =>
                              setFormData({
                                ...formData,
                                basePrice: parseFloat(e.target.value) || undefined,
                              })
                            }
                            className="mt-1.5"
                          />
                          <p className="text-xs text-muted-foreground mt-1">
                            Tarifa inicial
                          </p>
                        </div>
                        <div>
                          <Label htmlFor="pricePerKm">Precio por km (CHF)</Label>
                          <Input
                            id="pricePerKm"
                            type="number"
                            min={0}
                            step="0.1"
                            placeholder="Ej: 2.50"
                            value={formData.pricePerKm || ""}
                            onChange={(e) =>
                              setFormData({
                                ...formData,
                                pricePerKm: parseFloat(e.target.value) || undefined,
                              })
                            }
                            className="mt-1.5"
                          />
                          <p className="text-xs text-muted-foreground mt-1">
                            Por kilómetro
                          </p>
                        </div>
                        <div>
                          <Label htmlFor="hourlyRate">Tarifa hora (CHF)</Label>
                          <Input
                            id="hourlyRate"
                            type="number"
                            min={0}
                            placeholder="Ej: 60"
                            value={formData.hourlyRate || ""}
                            onChange={(e) =>
                              setFormData({
                                ...formData,
                                hourlyRate: parseFloat(e.target.value) || undefined,
                              })
                            }
                            className="mt-1.5"
                          />
                          <p className="text-xs text-muted-foreground mt-1">
                            Para limusinas
                          </p>
                        </div>
                      </div>

                      <Separator className="my-4" />

                      {/* Specific Routes */}
                      <div>
                        <Label className="flex items-center gap-2">
                          <Route className="h-4 w-4" />
                          Rutas específicas con precio fijo
                        </Label>
                        <p className="text-xs text-muted-foreground mb-3">
                          Añade rutas populares con precio fijo
                        </p>

                        {/* Add new route */}
                        <div className="flex flex-col sm:flex-row gap-2 mb-4">
                          <Input
                            placeholder="Origen (ej: Zürich)"
                            value={newRoute.origin}
                            onChange={(e) => setNewRoute({ ...newRoute, origin: e.target.value })}
                            className="flex-1"
                          />
                          <Input
                            placeholder="Destino (ej: Aeropuerto)"
                            value={newRoute.destination}
                            onChange={(e) => setNewRoute({ ...newRoute, destination: e.target.value })}
                            className="flex-1"
                          />
                          <Input
                            type="number"
                            placeholder="Precio CHF"
                            value={newRoute.price || ""}
                            onChange={(e) => setNewRoute({ ...newRoute, price: parseFloat(e.target.value) || undefined })}
                            className="w-28"
                          />
                          <Button
                            type="button"
                            variant="outline"
                            onClick={addRoute}
                            disabled={!newRoute.origin || !newRoute.destination}
                          >
                            <Plus className="h-4 w-4" />
                          </Button>
                        </div>

                        {/* Popular route suggestions */}
                        <div className="flex flex-wrap gap-2 mb-4">
                          {popularRoutes.map((route, i) => (
                            <Badge
                              key={i}
                              variant="outline"
                              className="cursor-pointer hover:bg-muted"
                              onClick={() => setNewRoute({ ...newRoute, origin: route.origin, destination: route.destination })}
                            >
                              {route.origin} → {route.destination}
                            </Badge>
                          ))}
                        </div>

                        {/* List of added routes */}
                        {routes.length > 0 && (
                          <div className="space-y-2">
                            {routes.map((route, index) => (
                              <div
                                key={index}
                                className="flex items-center justify-between p-3 rounded-lg bg-muted/50 border border-border"
                              >
                                <div>
                                  <span className="font-medium">{route.origin}</span>
                                  <span className="mx-2 text-muted-foreground">→</span>
                                  <span className="font-medium">{route.destination}</span>
                                </div>
                                <div className="flex items-center gap-3">
                                  {route.price && (
                                    <span className="text-yellow-400 font-medium">
                                      CHF {route.price}
                                    </span>
                                  )}
                                  <Button
                                    type="button"
                                    variant="ghost"
                                    size="icon"
                                    className="h-8 w-8 text-destructive hover:text-destructive"
                                    onClick={() => removeRoute(index)}
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}

              {/* Step 6: Schedule */}
              {currentStep === 6 && (
                <motion.div
                  key="step6"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-6"
                >
                  <div>
                    <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                      <Clock className="h-5 w-5 text-yellow-400" />
                      Horarios de disponibilidad
                    </h2>

                    <div className="space-y-4">
                      {/* 24/7 toggle */}
                      <div className="flex items-center space-x-2 p-4 rounded-lg bg-green-500/10 border border-green-500/30">
                        <Checkbox
                          id="available24h"
                          checked={formData.isAvailable24h}
                          onCheckedChange={(checked) =>
                            setFormData({
                              ...formData,
                              isAvailable24h: checked as boolean,
                            })
                          }
                        />
                        <Label
                          htmlFor="available24h"
                          className="text-sm cursor-pointer flex items-center gap-2"
                        >
                          <Clock className="h-4 w-4 text-green-500" />
                          <span className="font-medium text-green-500">
                            Disponible 24 horas, 7 días
                          </span>
                        </Label>
                      </div>

                      {/* Custom schedules */}
                      {!formData.isAvailable24h && (
                        <div className="space-y-3">
                          <p className="text-sm text-muted-foreground">
                            Define tus horarios de disponibilidad
                          </p>
                          {daysOfWeek.map((day) => {
                            const schedule = schedules.find(s => s.dayOfWeek === day.value);
                            if (!schedule) return null;
                            
                            return (
                              <div
                                key={day.value}
                                className={`flex flex-col sm:flex-row sm:items-center gap-3 p-3 rounded-lg border transition-all ${
                                  schedule.isActive
                                    ? "border-yellow-400/50 bg-yellow-400/5"
                                    : "border-border bg-muted/30 opacity-60"
                                }`}
                              >
                                <div className="flex items-center gap-3 w-full sm:w-32">
                                  <Checkbox
                                    checked={schedule.isActive}
                                    onCheckedChange={() => toggleSchedule(day.value)}
                                  />
                                  <span className="font-medium">{day.label}</span>
                                </div>
                                {schedule.isActive && (
                                  <div className="flex items-center gap-2 flex-1">
                                    <Input
                                      type="time"
                                      value={schedule.startTime}
                                      onChange={(e) => updateScheduleTime(day.value, 'startTime', e.target.value)}
                                      className="w-28"
                                    />
                                    <span className="text-muted-foreground">a</span>
                                    <Input
                                      type="time"
                                      value={schedule.endTime}
                                      onChange={(e) => updateScheduleTime(day.value, 'endTime', e.target.value)}
                                      className="w-28"
                                    />
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  </div>
                </motion.div>
              )}

              {/* Step 7: Description */}
              {currentStep === 7 && (
                <motion.div
                  key="step7"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-6"
                >
                  <div>
                    <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                      <FileText className="h-5 w-5 text-yellow-400" />
                      Descripción de tu perfil
                    </h2>

                    <div className="space-y-4">
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <Label htmlFor="description">Cuéntanos sobre ti</Label>
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={generateAIDescription}
                            disabled={isGeneratingAI}
                            className="border-yellow-400/50 text-yellow-400 hover:bg-yellow-400/10"
                          >
                            {isGeneratingAI ? (
                              <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Generando...
                              </>
                            ) : (
                              <>
                                <Wand2 className="mr-2 h-4 w-4" />
                                Generar con IA
                              </>
                            )}
                          </Button>
                        </div>
                        <Textarea
                          id="description"
                          placeholder="Escribe una descripción profesional sobre tu servicio de taxi. Nuestra IA puede ayudarte a generar un texto profesional."
                          value={formData.description}
                          onChange={(e) =>
                            setFormData({ ...formData, description: e.target.value })
                          }
                          className="min-h-[200px]"
                        />
                        <p className="text-xs text-muted-foreground mt-2">
                          <Sparkles className="inline h-3 w-3 mr-1" />
                          La IA generará un texto profesional basado en tu información
                        </p>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}

              {/* Step 8: Preview */}
              {currentStep === 8 && (
                <motion.div
                  key="step8"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-6"
                >
                  <div>
                    <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
                      <Eye className="h-5 w-5 text-yellow-400" />
                      Vista previa de tu perfil
                    </h2>

                    <div className="space-y-6">
                      {/* Profile preview card */}
                      <Card className="border-border overflow-hidden">
                        <div className="h-32 bg-gradient-to-br from-yellow-400/20 to-yellow-400/5" />
                        <CardContent className="p-4 -mt-8">
                          <div className="flex items-end gap-4">
                            {imagePreview ? (
                              <img
                                src={imagePreview}
                                alt="Profile"
                                className="w-20 h-20 rounded-lg object-cover border-4 border-background"
                              />
                            ) : (
                              <div className="w-20 h-20 rounded-lg bg-yellow-400/20 border-4 border-background flex items-center justify-center">
                                <Car className="h-8 w-8 text-yellow-400" />
                              </div>
                            )}
                            <div>
                              <h3 className="text-xl font-bold">{formData.name || "Tu nombre"}</h3>
                              <p className="text-muted-foreground flex items-center gap-1">
                                <MapPin className="h-4 w-4" />
                                {cityName || "Ciudad"}, {cantonName || "Cantón"}
                              </p>
                            </div>
                          </div>
                          
                          <div className="mt-4 flex flex-wrap gap-2">
                            {formData.services.map(serviceId => {
                              const service = serviceOptions.find(s => s.id === serviceId);
                              return service ? (
                                <Badge key={serviceId} variant="secondary">
                                  {service.label}
                                </Badge>
                              ) : null;
                            })}
                          </div>

                          {formData.isAvailable24h && (
                            <Badge className="mt-3 bg-green-500/10 text-green-500 border-green-500/30">
                              <Clock className="mr-1 h-3 w-3" />
                              Disponible 24/7
                            </Badge>
                          )}

                          {formData.description && (
                            <p className="mt-4 text-sm text-muted-foreground">
                              {formData.description}
                            </p>
                          )}

                          <Separator className="my-4" />

                          {/* Prices preview */}
                          {(formData.basePrice || formData.pricePerKm || formData.hourlyRate) && (
                            <div className="grid grid-cols-3 gap-4 text-center">
                              {formData.basePrice && (
                                <div>
                                  <div className="text-lg font-bold text-yellow-400">
                                    CHF {formData.basePrice}
                                  </div>
                                  <div className="text-xs text-muted-foreground">Precio base</div>
                                </div>
                              )}
                              {formData.pricePerKm && (
                                <div>
                                  <div className="text-lg font-bold text-yellow-400">
                                    CHF {formData.pricePerKm}/km
                                  </div>
                                  <div className="text-xs text-muted-foreground">Por kilómetro</div>
                                </div>
                              )}
                              {formData.hourlyRate && (
                                <div>
                                  <div className="text-lg font-bold text-yellow-400">
                                    CHF {formData.hourlyRate}/h
                                  </div>
                                  <div className="text-xs text-muted-foreground">Tarifa hora</div>
                                </div>
                              )}
                            </div>
                          )}

                          {/* Routes preview */}
                          {routes.length > 0 && (
                            <div className="mt-4">
                              <h4 className="font-medium mb-2 flex items-center gap-2">
                                <Route className="h-4 w-4 text-yellow-400" />
                                Rutas
                              </h4>
                              <div className="flex flex-wrap gap-2">
                                {routes.map((route, i) => (
                                  <Badge key={i} variant="outline">
                                    {route.origin} → {route.destination}
                                    {route.price && ` (CHF ${route.price})`}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          )}

                          {/* Social media preview */}
                          {(formData.website || formData.instagram || formData.facebook) && (
                            <div className="mt-4 flex gap-3">
                              {formData.website && (
                                <LinkIcon className="h-5 w-5 text-muted-foreground" />
                              )}
                              {formData.instagram && (
                                <Instagram className="h-5 w-5 text-pink-500" />
                              )}
                              {formData.facebook && (
                                <Facebook className="h-5 w-5 text-blue-500" />
                              )}
                            </div>
                          )}
                        </CardContent>
                      </Card>

                      <div className="bg-muted/50 p-4 rounded-lg">
                        <p className="text-sm text-muted-foreground">
                          Al crear tu perfil, aceptas nuestros términos de servicio. 
                          Tu información será visible públicamente en la plataforma.
                        </p>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Navigation buttons */}
            <div className="flex justify-between mt-8 pt-6 border-t border-border">
              <Button
                type="button"
                variant="outline"
                onClick={prevStep}
                disabled={currentStep === 1}
              >
                <ArrowLeft className="mr-2 h-4 w-4" />
                Anterior
              </Button>

              {currentStep < 8 ? (
                <Button
                  type="button"
                  className="bg-yellow-400 text-black hover:bg-yellow-500"
                  onClick={nextStep}
                >
                  Siguiente
                  <Check className="ml-2 h-4 w-4" />
                </Button>
              ) : (
                <Button
                  type="button"
                  className="bg-yellow-400 text-black hover:bg-yellow-500"
                  onClick={handleSubmit}
                  disabled={isSubmitting}
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Creando perfil...
                    </>
                  ) : (
                    <>
                      <Check className="mr-2 h-4 w-4" />
                      Crear perfil
                    </>
                  )}
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
