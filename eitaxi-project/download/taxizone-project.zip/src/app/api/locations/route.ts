import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const query = searchParams.get('q')?.toLowerCase() || ''
    const type = searchParams.get('type') || 'all' // 'cities', 'cantons', 'all'
    
    if (!query || query.length < 2) {
      return NextResponse.json({
        success: true,
        data: { cities: [], cantons: [], combined: [] }
      })
    }

    const results: {
      cities: Array<{ id: string; name: string; cantonName: string; type: 'city' }>
      cantons: Array<{ id: string; name: string; code: string; type: 'canton' }>
      combined: Array<{ id: string; name: string; type: 'city' | 'canton'; cantonName?: string; code?: string }>
    } = { cities: [], cantons: [], combined: [] }

    // Search cantons
    if (type === 'all' || type === 'cantons') {
      const cantons = await db.canton.findMany({
        where: {
          OR: [
            { name: { contains: query } },
            { code: { contains: query.toUpperCase() } }
          ]
        },
        take: 5
      })
      results.cantons = cantons.map(c => ({
        id: c.id,
        name: c.name,
        code: c.code,
        type: 'canton' as const
      }))
    }

    // Search cities
    if (type === 'all' || type === 'cities') {
      const cities = await db.city.findMany({
        where: {
          name: { contains: query }
        },
        include: {
          canton: true
        },
        take: 10
      })
      results.cities = cities.map(c => ({
        id: c.id,
        name: c.name,
        cantonName: c.canton.name,
        type: 'city' as const
      }))
    }

    // Combine results for easy use
    results.combined = [
      ...results.cantons,
      ...results.cities
    ]

    return NextResponse.json({
      success: true,
      data: results
    })
  } catch (error) {
    console.error('Error searching locations:', error)
    return NextResponse.json(
      { success: false, error: 'Error al buscar ubicaciones' },
      { status: 500 }
    )
  }
}
