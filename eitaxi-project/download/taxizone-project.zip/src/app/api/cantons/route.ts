import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const cantons = await db.canton.findMany({
      include: {
        cities: {
          orderBy: { name: 'asc' },
        },
        _count: {
          select: { drivers: true },
        },
      },
      orderBy: { name: 'asc' },
    })

    return NextResponse.json({
      success: true,
      data: cantons,
    })
  } catch (error) {
    console.error('Error fetching cantons:', error)
    return NextResponse.json(
      { success: false, error: 'Error al obtener cantones' },
      { status: 500 }
    )
  }
}
