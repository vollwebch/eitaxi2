import { NextRequest, NextResponse } from "next/server";
import ZAI from "z-ai-web-dev-sdk";

// Fallback function to generate description without AI
function generateFallbackDescription(
  name: string,
  services: string[],
  experience: number,
  vehicleDesc: string,
  city: string,
  canton: string,
  languageList: string
): string {
  const serviceDescriptions: Record<string, string> = {
    airport: "traslados al aeropuerto",
    city: "viajes dentro de la ciudad",
    long_distance: "recorridos de larga distancia",
    limousine: "servicio de limusina de lujo",
    corporate: "transporte corporativo para empresas",
    events: "servicio para eventos y celebraciones",
    delivery: "entregas y mensajería",
    night: "servicio nocturno seguro",
  };

  const mainServices = services.slice(0, 3).map(s => serviceDescriptions[s] || s);
  const location = city && canton ? `en ${city}, ${canton}` : city ? `en ${city}` : canton ? `en el cantón de ${canton}` : "en Suiza";
  
  const descriptions = [
    `Conductor profesional con más de ${experience} años de experiencia ${location}. Especializado en ${mainServices.join(", ")}. Ofrezco un servicio seguro, puntual y confortable para todos mis pasajeros. Disponible para viajes locales y de larga distancia.`,
    
    `Servicio de transporte profesional ${location} con ${experience} años de experiencia. Mi ${vehicleDesc} está equipado para brindarte la mejor experiencia en ${mainServices.join(", ")}. Hablo ${languageList}. Servicio disponible 24/7.`,
    
    `Profesional del transporte con ${experience}+ años de experiencia ${location}. Me especializo en ${mainServices.join(", ")} y ofrezco un servicio personalizado y de alta calidad. Vehículo confortable y bien mantenido. ¡Contáctame para tu próximo viaje!`,
  ];
  
  return descriptions[Math.floor(Math.random() * descriptions.length)];
}

export async function POST(request: NextRequest) {
  // Parse body once at the beginning
  let body;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json(
      { success: false, error: "Error al procesar la solicitud" },
      { status: 400 }
    );
  }

  const { name, services, experience, vehicleType, vehicleTypes, city, canton, languages } = body;

  // Validate required fields
  if (!name) {
    return NextResponse.json(
      { success: false, error: "El nombre es requerido" },
      { status: 400 }
    );
  }

  if (!services || services.length === 0) {
    return NextResponse.json(
      { success: false, error: "Selecciona al menos un servicio" },
      { status: 400 }
    );
  }

  // Create service descriptions
  const serviceDescriptions: Record<string, string> = {
    airport: "traslados al aeropuerto",
    city: "viajes dentro de la ciudad",
    long_distance: "recorridos de larga distancia",
    limousine: "servicio de limusina de lujo",
    corporate: "transporte corporativo para empresas",
    events: "servicio para eventos y celebraciones",
    delivery: "entregas y mensajería",
    night: "servicio nocturno seguro",
  };

  const serviceList = services
    .map((s: string) => serviceDescriptions[s] || s)
    .join(", ");

  // Get vehicle type (support both single and multiple)
  const primaryVehicleType = vehicleTypes?.[0] || vehicleType || "taxi";
  const vehicleDescriptions: Record<string, string> = {
    taxi: "taxi estándar",
    limousine: "limusina de lujo",
    van: "van amplia para grupos",
    premium: "vehículo premium ejecutivo",
  };

  const vehicleDesc = vehicleDescriptions[primaryVehicleType] || "vehículo";

  // Language names
  const languageNames: Record<string, string> = {
    de: "alemán",
    en: "inglés",
    fr: "francés",
    it: "italiano",
    es: "español",
    pt: "portugués",
    ru: "ruso",
    zh: "chino",
  };

  const languageList = languages && languages.length > 0
    ? languages.map((l: string) => languageNames[l] || l).join(", ")
    : "varios idiomas";

  // Prepare fallback description data
  const fallbackDesc = generateFallbackDescription(
    name, services, experience || 1, vehicleDesc, city || "", canton || "", languageList
  );

  try {
    // Create prompt for AI
    const prompt = `Eres un experto en marketing para servicios de transporte. Crea una descripción profesional y atractiva para un perfil de conductor de taxi en Suiza.

DATOS DEL CONDUCTOR:
- Nombre: ${name}
- Experiencia: ${experience || 1} años
- Tipo de vehículo: ${vehicleDesc}
- Ciudad: ${city || "Suiza"}
- Cantón: ${canton || ""}
- Servicios: ${serviceList}
- Idiomas: ${languageList}

INSTRUCCIONES:
1. Escribe en español, un texto profesional de 2-3 párrafos (máximo 300 caracteres)
2. Destaca la experiencia y profesionalidad
3. Menciona los servicios principales de forma natural
4. Incluye la ubicación si está disponible
5. Menciona disponibilidad si es relevante
6. El tono debe ser profesional pero cercano
7. NO uses comillas ni caracteres especiales
8. NO incluyas el nombre del conductor al inicio de la descripción

Genera SOLO el texto de la descripción, sin títulos ni explicaciones adicionales.`;

    // Create AI instance
    const zai = await ZAI.create();

    // Call the AI with timeout
    const completion = await Promise.race([
      zai.chat.completions.create({
        messages: [
          {
            role: "system",
            content: "Eres un experto en marketing digital para servicios de transporte en Suiza. Escribes descripciones profesionales, atractivas y optimizadas para SEO."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        temperature: 0.7,
        max_tokens: 500,
      }),
      new Promise<null>((_, reject) => 
        setTimeout(() => reject(new Error("AI request timeout")), 10000)
      )
    ]);

    // Extract the description
    const description = completion && typeof completion === 'object' && 'choices' in completion
      ? completion.choices[0]?.message?.content?.trim() 
      : "";

    if (description) {
      return NextResponse.json({
        success: true,
        description,
        generatedBy: "ai"
      });
    }

    // Use fallback if AI returns empty
    return NextResponse.json({
      success: true,
      description: fallbackDesc,
      generatedBy: "fallback"
    });

  } catch (error) {
    console.error("Error generating description with AI, using fallback:", error);
    
    // Use fallback on any error (including rate limits)
    return NextResponse.json({
      success: true,
      description: fallbackDesc,
      generatedBy: "fallback"
    });
  }
}
