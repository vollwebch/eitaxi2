import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const cantonSlug = searchParams.get('canton')
    const citySlug = searchParams.get('city')
    const service = searchParams.get('service')
    const vehicleType = searchParams.get('vehicleType')

    const where: Record<string, unknown> = { isActive: true }

    if (cantonSlug) {
      where.canton = { slug: cantonSlug }
    }

    if (citySlug) {
      where.city = { slug: citySlug }
    }

    if (vehicleType) {
      where.vehicleType = vehicleType
    }

    let drivers = await db.taxiDriver.findMany({
      where,
      include: {
        city: true,
        canton: true,
      },
      orderBy: [
        { isTopRated: 'desc' },
        { subscription: 'desc' },
        { views: 'desc' },
      ],
    })

    // Parse JSON fields
    drivers = drivers.map(driver => ({
      ...driver,
      services: JSON.parse(driver.services as string) as string[],
      routes: JSON.parse(driver.routes as string) as string[],
      languages: JSON.parse(driver.languages as string) as string[],
      serviceZones: JSON.parse(driver.serviceZones as string) as string[],
    }))

    // Filter by service if specified
    if (service) {
      drivers = drivers.filter(d => d.services.includes(service))
    }

    return NextResponse.json({
      success: true,
      data: drivers,
      total: drivers.length,
    })
  } catch (error) {
    console.error('Error fetching taxi drivers:', error)
    return NextResponse.json(
      { success: false, error: 'Error al obtener taxistas' },
      { status: 500 }
    )
  }
}
