import { NextRequest, NextResponse } from 'next/server'
import bcrypt from 'bcryptjs'
import { db } from '@/lib/db'

// Función para generar slug único
async function generateUniqueSlug(name: string): Promise<string> {
  const baseSlug = name
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '') // Remove accents
    .replace(/[^a-z0-9\s-]/g, '')
    .replace(/\s+/g, '-')
    .substring(0, 30)
  
  let slug = baseSlug
  let counter = 1
  
  while (await db.taxiDriver.findUnique({ where: { slug } })) {
    slug = `${baseSlug}-${counter}`
    counter++
  }
  
  return slug
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    
    const {
      name,
      phone,
      whatsapp,
      email,
      cityId,
      cantonId,
      address,
      experience,
      description,
      originalDescription,
      services,
      languages,
      serviceZones,
      isAvailable24h,
      vehicleType,
      vehicleTypes,
      vehicleBrand,
      vehicleModel,
      vehicleYear,
      vehicleColor,
      passengerCapacity,
      imageUrl,
      // New price fields
      basePrice,
      pricePerKm,
      hourlyRate,
      // Social media
      website,
      instagram,
      facebook,
      // Routes
      routes,
      // Schedules
      schedules,
      subscription = 'free',
    } = body

    // Validaciones básicas
    if (!name || !phone || !cityId || !cantonId || !email || !body.password) {
      return NextResponse.json(
        { success: false, error: 'Faltan campos obligatorios: nombre, email, contraseña, teléfono, ciudad y cantón son requeridos' },
        { status: 400 }
      )
    }

    // Check if email already exists
    const existingDriver = await db.taxiDriver.findUnique({
      where: { email: email.toLowerCase() }
    })
    if (existingDriver) {
      return NextResponse.json(
        { success: false, error: 'Este email ya está registrado. Intenta con otro o inicia sesión.' },
        { status: 400 }
      )
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(body.password, 10)

    // Verificar que la ciudad y cantón existen
    const city = await db.city.findUnique({ 
      where: { id: cityId },
      include: { canton: true }
    })
    
    if (!city) {
      return NextResponse.json(
        { success: false, error: 'Ciudad no encontrada' },
        { status: 400 }
      )
    }

    if (city.cantonId !== cantonId) {
      return NextResponse.json(
        { success: false, error: 'La ciudad no pertenece al cantón seleccionado' },
        { status: 400 }
      )
    }

    const canton = city.canton

    // Generar slug único
    const slug = await generateUniqueSlug(name)

    // Si no hay servicios, asignar por defecto
    const finalServices = services && services.length > 0 
      ? services 
      : ['city']

    // Usar el primer tipo de vehículo como principal
    const primaryVehicleType = vehicleTypes && vehicleTypes.length > 0 
      ? vehicleTypes[0] 
      : vehicleType || 'taxi'

    // Crear el conductor con todos los campos nuevos
    const driver = await db.taxiDriver.create({
      data: {
        name,
        slug,
        phone,
        whatsapp: whatsapp || null,
        email: email.toLowerCase(),
        password: hashedPassword,
        cityId,
        cantonId,
        address: address || null,
        experience: experience || 1,
        description: description || null,
        originalDescription: originalDescription || null,
        imageUrl: imageUrl || null,
        vehicleType: primaryVehicleType,
        vehicleBrand: vehicleBrand || null,
        vehicleModel: vehicleModel || null,
        vehicleYear: vehicleYear || null,
        vehicleColor: vehicleColor || null,
        passengerCapacity: passengerCapacity || null,
        isAvailable24h: isAvailable24h ?? true,
        services: JSON.stringify(finalServices),
        languages: JSON.stringify(languages || []),
        serviceZones: JSON.stringify(serviceZones || []),
        routes: JSON.stringify(routes || []),
        workingHours: isAvailable24h ? null : JSON.stringify(schedules || []),
        // New price fields
        basePrice: basePrice || null,
        pricePerKm: pricePerKm || null,
        hourlyRate: hourlyRate || null,
        // Social media
        website: website || null,
        instagram: instagram || null,
        facebook: facebook || null,
        subscription,
        isVerified: false,
        isTopRated: false,
      },
      include: {
        city: true,
        canton: true,
      },
    })

    // Crear las rutas específicas del conductor
    if (routes && routes.length > 0) {
      await db.driverRoute.createMany({
        data: routes.map((route: { origin: string; destination: string; price?: number }) => ({
          driverId: driver.id,
          origin: route.origin,
          destination: route.destination,
          price: route.price || null,
        })),
        skipDuplicates: true,
      })
    }

    // Crear los horarios específicos si no es 24/7
    if (!isAvailable24h && schedules && schedules.length > 0) {
      await db.driverSchedule.createMany({
        data: schedules.map((schedule: { dayOfWeek: number; startTime: string; endTime: string; isActive: boolean }) => ({
          driverId: driver.id,
          dayOfWeek: schedule.dayOfWeek,
          startTime: schedule.startTime,
          endTime: schedule.endTime,
          isActive: schedule.isActive ?? true,
        })),
        skipDuplicates: true,
      })
    }

    // Obtener el conductor con las relaciones
    const driverWithRoutes = await db.taxiDriver.findUnique({
      where: { id: driver.id },
      include: {
        city: true,
        canton: true,
        driverRoutes: true,
        schedules: true,
      },
    })

    return NextResponse.json({
      success: true,
      data: {
        id: driver.id,
        name: driver.name,
        slug: driver.slug,
        city: driver.city,
        canton: driver.canton,
        services: JSON.parse(driver.services as string),
        languages: JSON.parse(driver.languages as string),
        serviceZones: JSON.parse(driver.serviceZones as string),
        routes: JSON.parse(driver.routes as string),
        vehicleType: driver.vehicleType,
        vehicleTypes: vehicleTypes || [primaryVehicleType],
        basePrice: driver.basePrice,
        pricePerKm: driver.pricePerKm,
        hourlyRate: driver.hourlyRate,
        website: driver.website,
        instagram: driver.instagram,
        facebook: driver.facebook,
        driverRoutes: driverWithRoutes?.driverRoutes || [],
        schedules: driverWithRoutes?.schedules || [],
      },
      profileUrl: `/${canton.slug}/${city.slug}/${slug}`,
    })
  } catch (error) {
    console.error('Error creating taxi driver:', error)
    return NextResponse.json(
      { success: false, error: 'Error al crear el perfil. Por favor intenta de nuevo.' },
      { status: 500 }
    )
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const slug = searchParams.get('slug')
    const cantonSlug = searchParams.get('canton')
    const citySlug = searchParams.get('city')
    const id = searchParams.get('id')

    // Get single driver by ID (for dashboard)
    if (id && !slug) {
      const driver = await db.taxiDriver.findUnique({
        where: { id },
        include: {
          city: true,
          canton: true,
          driverRoutes: true,
          schedules: true,
        },
      })

      if (!driver) {
        return NextResponse.json(
          { success: false, error: 'Conductor no encontrado' },
          { status: 404 }
        )
      }

      return NextResponse.json({
        success: true,
        data: {
          ...driver,
          services: JSON.parse(driver.services as string),
          routes: JSON.parse(driver.routes as string),
          languages: JSON.parse(driver.languages as string),
          serviceZones: JSON.parse(driver.serviceZones as string),
          workingHours: driver.workingHours ? JSON.parse(driver.workingHours as string) : null,
        },
      })
    }

    // Get single driver by slug
    if (slug) {
      const where: Record<string, unknown> = { 
        slug, 
        isActive: true 
      }

      if (cantonSlug) {
        where.canton = { slug: cantonSlug }
      }
      if (citySlug) {
        where.city = { slug: citySlug }
      }

      const driver = await db.taxiDriver.findFirst({
        where,
        include: {
          city: true,
          canton: true,
          driverRoutes: true,
          schedules: true,
        },
      })

      if (!driver) {
        return NextResponse.json(
          { success: false, error: 'Conductor no encontrado' },
          { status: 404 }
        )
      }

      // Incrementar vistas
      await db.taxiDriver.update({
        where: { id: driver.id },
        data: { views: { increment: 1 } },
      })

      return NextResponse.json({
        success: true,
        data: {
          ...driver,
          services: JSON.parse(driver.services as string),
          routes: JSON.parse(driver.routes as string),
          languages: JSON.parse(driver.languages as string),
          serviceZones: JSON.parse(driver.serviceZones as string),
          workingHours: driver.workingHours ? JSON.parse(driver.workingHours as string) : null,
        },
      })
    }

    // Listar todos con filtros
    const canton = searchParams.get('canton')
    const city = searchParams.get('city')
    const service = searchParams.get('service')
    const vehicleType = searchParams.get('vehicleType')
    const available24h = searchParams.get('available24h')
    const limit = parseInt(searchParams.get('limit') || '20')

    const where: Record<string, unknown> = { isActive: true }

    if (canton) {
      where.canton = { slug: canton }
    }
    if (city) {
      where.city = { slug: city }
    }
    if (vehicleType) {
      where.vehicleType = vehicleType
    }
    if (available24h === 'true') {
      where.isAvailable24h = true
    }

    let drivers = await db.taxiDriver.findMany({
      where,
      include: { 
        city: true, 
        canton: true,
        driverRoutes: true,
      },
      orderBy: [
        { isTopRated: 'desc' },
        { subscription: 'desc' },
        { views: 'desc' },
      ],
      take: limit,
    })

    // Parsear JSON fields
    drivers = drivers.map(d => ({
      ...d,
      services: JSON.parse(d.services as string),
      routes: JSON.parse(d.routes as string),
      languages: JSON.parse(d.languages as string),
      serviceZones: JSON.parse(d.serviceZones as string),
    })) as typeof drivers

    // Filtrar por servicio en memoria
    if (service) {
      drivers = drivers.filter(d => (d.services as string[]).includes(service))
    }

    return NextResponse.json({
      success: true,
      data: drivers,
      total: drivers.length,
    })
  } catch (error) {
    console.error('Error fetching drivers:', error)
    return NextResponse.json(
      { success: false, error: 'Error al obtener conductores' },
      { status: 500 }
    )
  }
}

// PUT - Update driver (for dashboard)
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json()
    const { id, ...updateData } = body

    if (!id) {
      return NextResponse.json(
        { success: false, error: 'ID del conductor es requerido' },
        { status: 400 }
      )
    }

    // Verificar que el conductor existe
    const existingDriver = await db.taxiDriver.findUnique({
      where: { id },
    })

    if (!existingDriver) {
      return NextResponse.json(
        { success: false, error: 'Conductor no encontrado' },
        { status: 404 }
      )
    }

    // Preparar datos para actualizar
    const dataToUpdate: Record<string, unknown> = {}

    // Campos básicos
    const simpleFields = [
      'name', 'phone', 'whatsapp', 'email', 'address', 
      'experience', 'description', 'vehicleBrand', 'vehicleModel',
      'vehicleYear', 'vehicleColor', 'passengerCapacity', 'imageUrl',
      'basePrice', 'pricePerKm', 'hourlyRate', 'website', 'instagram',
      'facebook', 'isAvailable24h'
    ]

    simpleFields.forEach(field => {
      if (updateData[field] !== undefined) {
        dataToUpdate[field] = updateData[field]
      }
    })

    // Campos JSON
    if (updateData.services) {
      dataToUpdate.services = JSON.stringify(updateData.services)
    }
    if (updateData.languages) {
      dataToUpdate.languages = JSON.stringify(updateData.languages)
    }
    if (updateData.serviceZones) {
      dataToUpdate.serviceZones = JSON.stringify(updateData.serviceZones)
    }
    if (updateData.vehicleType) {
      dataToUpdate.vehicleType = updateData.vehicleType
    }

    // Actualizar el conductor
    const updatedDriver = await db.taxiDriver.update({
      where: { id },
      data: dataToUpdate,
      include: {
        city: true,
        canton: true,
        driverRoutes: true,
        schedules: true,
      },
    })

    // Actualizar rutas si se proporcionan
    if (updateData.routes && Array.isArray(updateData.routes)) {
      // Eliminar rutas existentes
      await db.driverRoute.deleteMany({
        where: { driverId: id },
      })
      
      // Crear nuevas rutas
      if (updateData.routes.length > 0) {
        await db.driverRoute.createMany({
          data: updateData.routes.map((route: { origin: string; destination: string; price?: number }) => ({
            driverId: id,
            origin: route.origin,
            destination: route.destination,
            price: route.price || null,
          })),
        })
      }
    }

    // Actualizar horarios si se proporcionan
    if (!updateData.isAvailable24h && updateData.schedules && Array.isArray(updateData.schedules)) {
      // Eliminar horarios existentes
      await db.driverSchedule.deleteMany({
        where: { driverId: id },
      })
      
      // Crear nuevos horarios
      if (updateData.schedules.length > 0) {
        await db.driverSchedule.createMany({
          data: updateData.schedules.map((schedule: { dayOfWeek: number; startTime: string; endTime: string; isActive: boolean }) => ({
            driverId: id,
            dayOfWeek: schedule.dayOfWeek,
            startTime: schedule.startTime,
            endTime: schedule.endTime,
            isActive: schedule.isActive ?? true,
          })),
        })
      }
    }

    return NextResponse.json({
      success: true,
      data: {
        ...updatedDriver,
        services: JSON.parse(updatedDriver.services as string),
        languages: JSON.parse(updatedDriver.languages as string),
        serviceZones: JSON.parse(updatedDriver.serviceZones as string),
        routes: JSON.parse(updatedDriver.routes as string),
      },
    })
  } catch (error) {
    console.error('Error updating driver:', error)
    return NextResponse.json(
      { success: false, error: 'Error al actualizar el perfil' },
      { status: 500 }
    )
  }
}
