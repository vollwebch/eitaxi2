import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

// Datos completos de Suiza con coordenadas
const swissData = [
  {
    name: "Zürich",
    code: "ZH",
    slug: "zurich",
    latitude: 47.3769,
    longitude: 8.5417,
    cities: [
      { name: "Zürich", slug: "zurich", latitude: 47.3769, longitude: 8.5417, postalCode: "8000" },
      { name: "Winterthur", slug: "winterthur", latitude: 47.4988, longitude: 8.7236, postalCode: "8400" },
      { name: "Uster", slug: "uster", latitude: 47.3483, longitude: 8.7178, postalCode: "8610" },
      { name: "Dübendorf", slug: "dubendorf", latitude: 47.3975, longitude: 8.6186, postalCode: "8600" },
      { name: "Dietikon", slug: "dietikon", latitude: 47.4056, longitude: 8.4031, postalCode: "8953" },
      { name: "Wetzikon", slug: "wetzikon", latitude: 47.3275, longitude: 8.7894, postalCode: "8620" },
      { name: "Horgen", slug: "horgen", latitude: 47.2606, longitude: 8.5953, postalCode: "8810" },
      { name: "Kloten", slug: "kloten", latitude: 47.4514, longitude: 8.5644, postalCode: "8302" },
      { name: "Wädenswil", slug: "wadenswil", latitude: 47.2244, longitude: 8.6783, postalCode: "8820" },
      { name: "Urdorf", slug: "urdorf", latitude: 47.3917, longitude: 8.4211, postalCode: "8902" },
      { name: "Thalwil", slug: "thalwil", latitude: 47.2906, longitude: 8.5642, postalCode: "8800" },
      { name: "Adliswil", slug: "adliswil", latitude: 47.3111, longitude: 8.5267, postalCode: "8134" },
      { name: "Regensdorf", slug: "regensdorf", latitude: 47.4308, longitude: 8.4694, postalCode: "8105" },
      { name: "Volketswil", slug: "volketswil", latitude: 47.3867, longitude: 8.6817, postalCode: "8604" },
      { name: "Bülach", slug: "bulach", latitude: 47.5186, longitude: 8.5367, postalCode: "8180" },
    ]
  },
  {
    name: "Bern",
    code: "BE",
    slug: "bern",
    latitude: 46.9480,
    longitude: 7.4474,
    cities: [
      { name: "Bern", slug: "bern", latitude: 46.9480, longitude: 7.4474, postalCode: "3000" },
      { name: "Biel/Bienne", slug: "biel", latitude: 47.1367, longitude: 7.2467, postalCode: "2500" },
      { name: "Thun", slug: "thun", latitude: 46.7583, longitude: 7.6286, postalCode: "3600" },
      { name: "Burgdorf", slug: "burgdorf", latitude: 47.0578, longitude: 7.6253, postalCode: "3400" },
      { name: "Langenthal", slug: "langenthal", latitude: 47.2117, longitude: 7.7889, postalCode: "4900" },
      { name: "Steffisburg", slug: "steffisburg", latitude: 46.7833, longitude: 7.6167, postalCode: "3612" },
      { name: "Köniz", slug: "koniz", latitude: 46.9236, longitude: 7.4167, postalCode: "3098" },
      { name: "Muri bei Bern", slug: "muri-bei-bern", latitude: 46.9333, longitude: 7.4833, postalCode: "3073" },
      { name: "Ittigen", slug: "ittigen", latitude: 46.9667, longitude: 7.4667, postalCode: "3063" },
      { name: "Münsingen", slug: "munsingen", latitude: 46.8722, longitude: 7.5597, postalCode: "3110" },
      { name: "Spiez", slug: "spiez", latitude: 46.6833, longitude: 7.6833, postalCode: "3700" },
      { name: "Interlaken", slug: "interlaken", latitude: 46.6833, longitude: 7.8667, postalCode: "3800" },
    ]
  },
  {
    name: "Geneva",
    code: "GE",
    slug: "geneva",
    latitude: 46.2044,
    longitude: 6.1432,
    cities: [
      { name: "Geneva", slug: "geneva", latitude: 46.2044, longitude: 6.1432, postalCode: "1200" },
      { name: "Vernier", slug: "vernier", latitude: 46.2181, longitude: 6.0944, postalCode: "1214" },
      { name: "Lancy", slug: "lancy", latitude: 46.1867, longitude: 6.1167, postalCode: "1212" },
      { name: "Meyrin", slug: "meyrin", latitude: 46.2275, longitude: 6.0733, postalCode: "1217" },
      { name: "Carouge", slug: "carouge", latitude: 46.1806, longitude: 6.1389, postalCode: "1227" },
      { name: "Onex", slug: "onex", latitude: 46.1789, longitude: 6.0925, postalCode: "1213" },
      { name: "Thônex", slug: "thonex", latitude: 46.1833, longitude: 6.2000, postalCode: "1226" },
      { name: "Versoix", slug: "versoix", latitude: 46.2789, longitude: 6.1669, postalCode: "1290" },
      { name: "Chêne-Bougeries", slug: "chene-bougeries", latitude: 46.1917, longitude: 6.1694, postalCode: "1224" },
      { name: "Plan-les-Ouates", slug: "plan-les-ouates", latitude: 46.1583, longitude: 6.1083, postalCode: "1228" },
    ]
  },
  {
    name: "Vaud",
    code: "VD",
    slug: "vaud",
    latitude: 46.6167,
    longitude: 6.6167,
    cities: [
      { name: "Lausanne", slug: "lausanne", latitude: 46.5197, longitude: 6.6323, postalCode: "1000" },
      { name: "Montreux", slug: "montreux", latitude: 46.4317, longitude: 6.9106, postalCode: "1820" },
      { name: "Yverdon-les-Bains", slug: "yverdon", latitude: 46.7789, longitude: 6.6417, postalCode: "1400" },
      { name: "Vevey", slug: "vevey", latitude: 46.4617, longitude: 6.8417, postalCode: "1800" },
      { name: "Nyon", slug: "nyon", latitude: 46.3817, longitude: 6.2389, postalCode: "1260" },
      { name: "Renens", slug: "renens", latitude: 46.5367, longitude: 6.5861, postalCode: "1020" },
      { name: "Morges", slug: "morges", latitude: 46.5153, longitude: 6.4961, postalCode: "1110" },
      { name: "Pully", slug: "pully", latitude: 46.5083, longitude: 6.6667, postalCode: "1009" },
      { name: "Crissier", slug: "crissier", latitude: 46.5544, longitude: 6.5767, postalCode: "1023" },
      { name: "Gland", slug: "gland", latitude: 46.4267, longitude: 6.2667, postalCode: "1196" },
      { name: "Aigle", slug: "aigle", latitude: 46.3167, longitude: 6.9667, postalCode: "1860" },
      { name: "Bulle", slug: "bulle", latitude: 46.6153, longitude: 7.0569, postalCode: "1630" },
    ]
  },
  {
    name: "Basel-Stadt",
    code: "BS",
    slug: "basel-stadt",
    latitude: 47.5596,
    longitude: 7.5886,
    cities: [
      { name: "Basel", slug: "basel", latitude: 47.5596, longitude: 7.5886, postalCode: "4000" },
    ]
  },
  {
    name: "Basel-Landschaft",
    code: "BL",
    slug: "basel-land",
    latitude: 47.4667,
    longitude: 7.7500,
    cities: [
      { name: "Liestal", slug: "liestal", latitude: 47.4833, longitude: 7.7333, postalCode: "4410" },
      { name: "Reinach", slug: "reinach", latitude: 47.4917, longitude: 7.6083, postalCode: "4153" },
      { name: "Allschwil", slug: "allschwil", latitude: 47.5508, longitude: 7.5358, postalCode: "4123" },
      { name: "Muttenz", slug: "muttenz", latitude: 47.5167, longitude: 7.6500, postalCode: "4132" },
      { name: "Pratteln", slug: "pratteln", latitude: 47.5167, longitude: 7.6833, postalCode: "4133" },
      { name: "Binningen", slug: "binningen", latitude: 47.5333, longitude: 7.5833, postalCode: "4102" },
      { name: "Birsfelden", slug: "birsfelden", latitude: 47.5500, longitude: 7.6333, postalCode: "4127" },
      { name: "Oberwil", slug: "oberwil", latitude: 47.5167, longitude: 7.5500, postalCode: "4104" },
    ]
  },
  {
    name: "Aargau",
    code: "AG",
    slug: "aargau",
    latitude: 47.3833,
    longitude: 8.0500,
    cities: [
      { name: "Aarau", slug: "aarau", latitude: 47.3917, longitude: 8.0500, postalCode: "5000" },
      { name: "Baden", slug: "baden", latitude: 47.4728, longitude: 8.3064, postalCode: "5400" },
      { name: "Wettingen", slug: "wettingen", latitude: 47.4603, longitude: 8.3172, postalCode: "5430" },
      { name: "Wohlen", slug: "wohlen", latitude: 47.3500, longitude: 8.2833, postalCode: "5610" },
      { name: "Rheinfelden", slug: "rheinfelden", latitude: 47.5500, longitude: 7.8000, postalCode: "4310" },
      { name: "Brugg", slug: "brugg", latitude: 47.4833, longitude: 8.2000, postalCode: "5200" },
      { name: "Zofingen", slug: "zofingen", latitude: 47.2833, longitude: 8.0333, postalCode: "4800" },
      { name: "Suhr", slug: "suhr", latitude: 47.3833, longitude: 8.0833, postalCode: "5034" },
      { name: "Dietikon", slug: "dietikon-ag", latitude: 47.4056, longitude: 8.4031, postalCode: "8953" },
      { name: "Möriken-Wildegg", slug: "moriken-wildegg", latitude: 47.4167, longitude: 8.1833, postalCode: "5103" },
    ]
  },
  {
    name: "Lucerne",
    code: "LU",
    slug: "lucerne",
    latitude: 47.0505,
    longitude: 8.3054,
    cities: [
      { name: "Lucerne", slug: "lucerne", latitude: 47.0505, longitude: 8.3054, postalCode: "6000" },
      { name: "Emmen", slug: "emmen", latitude: 47.0833, longitude: 8.3000, postalCode: "6032" },
      { name: "Kriens", slug: "kriens", latitude: 47.0333, longitude: 8.2667, postalCode: "6010" },
      { name: "Horw", slug: "horw", latitude: 47.0167, longitude: 8.3000, postalCode: "6048" },
      { name: "Sursee", slug: "sursee", latitude: 47.1711, longitude: 8.1083, postalCode: "6210" },
      { name: "Willisau", slug: "willisau", latitude: 47.1167, longitude: 8.0000, postalCode: "6130" },
      { name: "Wolhusen", slug: "wolhusen", latitude: 47.0667, longitude: 8.0667, postalCode: "6110" },
    ]
  },
  {
    name: "St. Gallen",
    code: "SG",
    slug: "st-gallen",
    latitude: 47.4245,
    longitude: 9.3767,
    cities: [
      { name: "St. Gallen", slug: "st-gallen", latitude: 47.4245, longitude: 9.3767, postalCode: "9000" },
      { name: "Rapperswil-Jona", slug: "rapperswil", latitude: 47.2267, longitude: 8.8167, postalCode: "8640" },
      { name: "Gossau", slug: "gossau", latitude: 47.4167, longitude: 9.2500, postalCode: "9200" },
      { name: "Wil", slug: "wil", latitude: 47.4619, longitude: 9.0461, postalCode: "9500" },
      { name: "Uzwil", slug: "uzwil", latitude: 47.4333, longitude: 9.1333, postalCode: "9240" },
      { name: "Altstätten", slug: "altstatten", latitude: 47.3667, longitude: 9.5500, postalCode: "9450" },
      { name: "Buchs", slug: "buchs", latitude: 47.4667, longitude: 9.4667, postalCode: "9470" },
      { name: "Flawil", slug: "flawil", latitude: 47.4000, longitude: 9.1833, postalCode: "9230" },
    ]
  },
  {
    name: "Ticino",
    code: "TI",
    slug: "ticino",
    latitude: 46.3317,
    longitude: 8.8003,
    cities: [
      { name: "Lugano", slug: "lugano", latitude: 46.0037, longitude: 8.9511, postalCode: "6900" },
      { name: "Bellinzona", slug: "bellinzona", latitude: 46.1947, longitude: 9.0219, postalCode: "6500" },
      { name: "Locarno", slug: "locarno", latitude: 46.1700, longitude: 8.8000, postalCode: "6600" },
      { name: "Chiasso", slug: "chiasso", latitude: 45.8333, longitude: 9.0333, postalCode: "6830" },
      { name: "Mendrisio", slug: "mendrisio", latitude: 45.8700, longitude: 8.9833, postalCode: "6850" },
      { name: "Lugano Paradiso", slug: "lugano-paradiso", latitude: 45.9931, longitude: 8.9533, postalCode: "6900" },
      { name: "Minusio", slug: "minusio", latitude: 46.1833, longitude: 8.8167, postalCode: "6648" },
      { name: "Biasca", slug: "biasca", latitude: 46.3667, longitude: 8.9667, postalCode: "6710" },
    ]
  },
  {
    name: "Valais",
    code: "VS",
    slug: "valais",
    latitude: 46.2094,
    longitude: 7.3586,
    cities: [
      { name: "Sion", slug: "sion", latitude: 46.2333, longitude: 7.3500, postalCode: "1950" },
      { name: "Martigny", slug: "martigny", latitude: 46.1000, longitude: 7.0667, postalCode: "1920" },
      { name: "Monthey", slug: "monthey", latitude: 46.2500, longitude: 6.9500, postalCode: "1870" },
      { name: "Brig-Glis", slug: "brig", latitude: 46.3167, longitude: 7.9833, postalCode: "3900" },
      { name: "Nendaz", slug: "nendaz", latitude: 46.1833, longitude: 7.3000, postalCode: "1997" },
      { name: "Sierre", slug: "sierre", latitude: 46.2833, longitude: 7.5333, postalCode: "3960" },
      { name: "Visp", slug: "visp", latitude: 46.3000, longitude: 7.8667, postalCode: "3930" },
      { name: "Crans-Montana", slug: "crans-montana", latitude: 46.3000, longitude: 7.4833, postalCode: "3963" },
      { name: "Verbier", slug: "verbier", latitude: 46.1000, longitude: 7.2167, postalCode: "1936" },
      { name: "Zermatt", slug: "zermatt", latitude: 46.0206, longitude: 7.7492, postalCode: "3920" },
    ]
  },
  {
    name: "Graubünden",
    code: "GR",
    slug: "graubunden",
    latitude: 46.6569,
    longitude: 9.5780,
    cities: [
      { name: "Chur", slug: "chur", latitude: 46.8500, longitude: 9.5333, postalCode: "7000" },
      { name: "Davos", slug: "davos", latitude: 46.8000, longitude: 9.8333, postalCode: "7270" },
      { name: "St. Moritz", slug: "st-moritz", latitude: 46.4833, longitude: 9.8333, postalCode: "7500" },
      { name: "Landquart", slug: "landquart", latitude: 46.9667, longitude: 9.5500, postalCode: "7302" },
      { name: "Domat/Ems", slug: "domat-ems", latitude: 46.8333, longitude: 9.4500, postalCode: "7013" },
    ]
  },
  {
    name: "Neuchâtel",
    code: "NE",
    slug: "neuchatel",
    latitude: 46.9917,
    longitude: 6.9269,
    cities: [
      { name: "Neuchâtel", slug: "neuchatel", latitude: 46.9917, longitude: 6.9269, postalCode: "2000" },
      { name: "La Chaux-de-Fonds", slug: "la-chaux-de-fonds", latitude: 47.1000, longitude: 6.8333, postalCode: "2300" },
      { name: "Le Locle", slug: "le-locle", latitude: 47.0500, longitude: 6.7500, postalCode: "2400" },
    ]
  },
  {
    name: "Fribourg",
    code: "FR",
    slug: "fribourg",
    latitude: 46.8065,
    longitude: 7.1618,
    cities: [
      { name: "Fribourg", slug: "fribourg", latitude: 46.8065, longitude: 7.1618, postalCode: "1700" },
      { name: "Bulle", slug: "bulle-fr", latitude: 46.6153, longitude: 7.0569, postalCode: "1630" },
      { name: "Villars-sur-Glâne", slug: "villars-sur-glane", latitude: 46.7833, longitude: 7.1000, postalCode: "1752" },
    ]
  },
  {
    name: "Solothurn",
    code: "SO",
    slug: "solothurn",
    latitude: 47.2088,
    longitude: 7.5376,
    cities: [
      { name: "Solothurn", slug: "solothurn", latitude: 47.2088, longitude: 7.5376, postalCode: "4500" },
      { name: "Olten", slug: "olten", latitude: 47.3500, longitude: 7.9000, postalCode: "4600" },
      { name: "Grenchen", slug: "grenchen", latitude: 47.1922, longitude: 7.3964, postalCode: "2540" },
    ]
  },
  {
    name: "Schaffhausen",
    code: "SH",
    slug: "schaffhausen",
    latitude: 47.6973,
    longitude: 8.6349,
    cities: [
      { name: "Schaffhausen", slug: "schaffhausen", latitude: 47.6973, longitude: 8.6349, postalCode: "8200" },
      { name: "Neuhausen am Rheinfall", slug: "neuhausen", latitude: 47.6833, longitude: 8.6167, postalCode: "8212" },
    ]
  },
  {
    name: "Thurgau",
    code: "TG",
    slug: "thurgau",
    latitude: 47.5833,
    longitude: 9.1000,
    cities: [
      { name: "Frauenfeld", slug: "frauenfeld", latitude: 47.5500, longitude: 8.9000, postalCode: "8500" },
      { name: "Kreuzlingen", slug: "kreuzlingen", latitude: 47.6500, longitude: 9.1667, postalCode: "8280" },
      { name: "Arbon", slug: "arbon", latitude: 47.5167, longitude: 9.4333, postalCode: "9320" },
      { name: "Weinfelden", slug: "weinfelden", latitude: 47.5667, longitude: 9.1000, postalCode: "8570" },
      { name: "Romanshorn", slug: "romanshorn", latitude: 47.5667, longitude: 9.3833, postalCode: "8590" },
      { name: "Amriswil", slug: "amriswil", latitude: 47.5500, longitude: 9.3000, postalCode: "8580" },
    ]
  },
  {
    name: "Zug",
    code: "ZG",
    slug: "zug",
    latitude: 47.1740,
    longitude: 8.5178,
    cities: [
      { name: "Zug", slug: "zug", latitude: 47.1740, longitude: 8.5178, postalCode: "6300" },
      { name: "Baar", slug: "baar", latitude: 47.1967, longitude: 8.5289, postalCode: "6340" },
      { name: "Cham", slug: "cham", latitude: 47.1819, longitude: 8.4631, postalCode: "6330" },
    ]
  },
  {
    name: "Jura",
    code: "JU",
    slug: "jura",
    latitude: 47.3500,
    longitude: 7.1500,
    cities: [
      { name: "Delémont", slug: "delemont", latitude: 47.3667, longitude: 7.3500, postalCode: "2800" },
      { name: "Porrentruy", slug: "porrentruy", latitude: 47.4167, longitude: 7.0833, postalCode: "2900" },
    ]
  },
  {
    name: "Appenzell Ausserrhoden",
    code: "AR",
    slug: "appenzell-ar",
    latitude: 47.3667,
    longitude: 9.3000,
    cities: [
      { name: "Herisau", slug: "herisau", latitude: 47.3833, longitude: 9.2833, postalCode: "9100" },
      { name: "Urnäsch", slug: "urnasch", latitude: 47.3167, longitude: 9.2667, postalCode: "9107" },
      { name: "Teufen", slug: "teufen", latitude: 47.3833, longitude: 9.3833, postalCode: "9053" },
    ]
  },
  {
    name: "Appenzell Innerrhoden",
    code: "AI",
    slug: "appenzell-ir",
    latitude: 47.3167,
    longitude: 9.4000,
    cities: [
      { name: "Appenzell", slug: "appenzell", latitude: 47.3167, longitude: 9.4000, postalCode: "9050" },
    ]
  },
  {
    name: "Nidwalden",
    code: "NW",
    slug: "nidwalden",
    latitude: 46.9253,
    longitude: 8.3833,
    cities: [
      { name: "Stans", slug: "stans", latitude: 46.9583, longitude: 8.3667, postalCode: "6370" },
      { name: "Hergiswil", slug: "hergiswil", latitude: 46.9833, longitude: 8.3083, postalCode: "6018" },
    ]
  },
  {
    name: "Obwalden",
    code: "OW",
    slug: "obwalden",
    latitude: 46.8619,
    longitude: 8.2417,
    cities: [
      { name: "Sarnen", slug: "sarnen", latitude: 46.9000, longitude: 8.2333, postalCode: "6060" },
      { name: "Alpnach", slug: "alpnach", latitude: 46.9500, longitude: 8.2667, postalCode: "6055" },
    ]
  },
  {
    name: "Glarus",
    code: "GL",
    slug: "glarus",
    latitude: 47.0333,
    longitude: 9.0667,
    cities: [
      { name: "Glarus", slug: "glarus", latitude: 47.0333, longitude: 9.0667, postalCode: "8750" },
    ]
  },
  {
    name: "Uri",
    code: "UR",
    slug: "uri",
    latitude: 46.8333,
    longitude: 8.6333,
    cities: [
      { name: "Altdorf", slug: "altdorf", latitude: 46.8833, longitude: 8.6333, postalCode: "6460" },
    ]
  },
  {
    name: "Schwyz",
    code: "SZ",
    slug: "schwyz",
    latitude: 47.0206,
    longitude: 8.6494,
    cities: [
      { name: "Schwyz", slug: "schwyz", latitude: 47.0206, longitude: 8.6494, postalCode: "6430" },
      { name: "Einsiedeln", slug: "einsiedeln", latitude: 47.1278, longitude: 8.7472, postalCode: "8840" },
      { name: "Küssnacht", slug: "kussnacht", latitude: 47.0833, longitude: 8.4333, postalCode: "6403" },
    ]
  },
]

// Lugares de interés importantes
const placesData = [
  // Aeropuertos
  { name: "Aeropuerto de Zürich", type: "airport", slug: "zurich-airport", latitude: 47.4647, longitude: 8.5492, isPopular: true },
  { name: "Aeropuerto de Ginebra", type: "airport", slug: "geneva-airport", latitude: 46.2380, longitude: 6.1089, isPopular: true },
  { name: "Aeropuerto de Basilea", type: "airport", slug: "basel-airport", latitude: 47.5897, longitude: 7.5299, isPopular: true },
  { name: "Aeropuerto de Berna", type: "airport", slug: "bern-airport", latitude: 46.9122, longitude: 7.4964, isPopular: true },
  
  // Estaciones de tren principales
  { name: "Estación Zürich HB", type: "station", slug: "zurich-hb", latitude: 47.3780, longitude: 8.5400, isPopular: true },
  { name: "Estación Bern", type: "station", slug: "bern-station", latitude: 46.9480, longitude: 7.4394, isPopular: true },
  { name: "Estación Geneva", type: "station", slug: "geneva-station", latitude: 46.2100, longitude: 6.1423, isPopular: true },
  { name: "Estación Basel SBB", type: "station", slug: "basel-sbb", latitude: 47.5475, longitude: 7.5897, isPopular: true },
  { name: "Estación Lausanne", type: "station", slug: "lausanne-station", latitude: 46.5167, longitude: 6.6292, isPopular: true },
  { name: "Estación Lucerne", type: "station", slug: "lucerne-station", latitude: 47.0497, longitude: 8.3103, isPopular: true },
  
  // Zonas populares
  { name: "Centro de Zürich", type: "area", slug: "zurich-center", latitude: 47.3700, longitude: 8.5400, isPopular: true },
  { name: "Centro de Ginebra", type: "area", slug: "geneva-center", latitude: 46.2022, longitude: 6.1457, isPopular: true },
  { name: "Centro de Berna", type: "area", slug: "bern-center", latitude: 46.9480, longitude: 7.4500, isPopular: true },
  { name: "Centro de Basilea", type: "area", slug: "basel-center", latitude: 47.5584, longitude: 7.5877, isPopular: true },
  
  // Zonas turísticas
  { name: "Zermatt", type: "landmark", slug: "zermatt-center", latitude: 46.0206, longitude: 7.7492, isPopular: true },
  { name: "Interlaken", type: "landmark", slug: "interlaken-center", latitude: 46.6833, longitude: 7.8667, isPopular: true },
  { name: "St. Moritz", type: "landmark", slug: "st-moritz-center", latitude: 46.4833, longitude: 9.8333, isPopular: true },
  { name: "Davos", type: "landmark", slug: "davos-center", latitude: 46.8000, longitude: 9.8333, isPopular: true },
  { name: "Jungfraujoch", type: "landmark", slug: "jungfraujoch", latitude: 46.5483, longitude: 7.9811, isPopular: true },
  { name: "Matterhorn", type: "landmark", slug: "matterhorn", latitude: 45.9766, longitude: 7.6586, isPopular: true },
  
  // Distritos financieros
  { name: "Zürich Bahnhofstrasse", type: "area", slug: "zurich-bahnhofstrasse", latitude: 47.3711, longitude: 8.5372, isPopular: true },
  { name: "Geneva Pâquis", type: "area", slug: "geneva-paquis", latitude: 46.2225, longitude: 6.1383, isPopular: true },
  
  // Zonas empresariales
  { name: "Zug Centro Empresarial", type: "area", slug: "zug-business", latitude: 47.1740, longitude: 8.5178, isPopular: true },
  { name: "Zürich Oerlikon", type: "area", slug: "zurich-oerlikon", latitude: 47.4119, longitude: 8.5433, isPopular: true },
  
  // Otros lugares importantes
  { name: "Cascadas del Rin", type: "landmark", slug: "rhine-falls", latitude: 47.6764, longitude: 8.6150, isPopular: true },
  { name: "Lago de Zürich", type: "landmark", slug: "lake-zurich", latitude: 47.3100, longitude: 8.5400, isPopular: true },
  { name: "Lago Lemán", type: "landmark", slug: "lake-geneva", latitude: 46.4500, longitude: 6.5500, isPopular: true },
  { name: "Palacio de las Naciones", type: "landmark", slug: "un-geneva", latitude: 46.2217, longitude: 6.1383, isPopular: true },
]

// Taxistas de ejemplo
const sampleDrivers = [
  {
    name: "Taxi Paco",
    slug: "taxi-paco",
    phone: "+41 79 123 45 67",
    whatsapp: "+41 79 123 45 67",
    email: "paco@eitaxi.ch",
    password: "demo123456",
    experience: 8,
    description: "Conductor profesional con más de 8 años de experiencia en Zürich y alrededores. Especializado en traslados al aeropuerto y servicios de larga distancia. Hablo español, alemán e inglés.",
    isAvailable24h: true,
    services: ["airport", "city", "long_distance", "corporate"],
    routes: ["zurich-airport", "zurich-stgallen", "zurich-bern"],
    languages: ["de", "en", "es"],
    serviceZones: ["Centro de la ciudad", "Aeropuerto", "Zona empresarial"],
    vehicleType: "taxi",
    vehicleBrand: "Mercedes",
    vehicleModel: "E-Class",
    vehicleYear: 2022,
    vehicleColor: "Negro",
    passengerCapacity: 4,
    subscription: "premium",
    isVerified: true,
    isTopRated: true,
    pricePerKm: 3.50,
    basePrice: 6.00,
  },
  {
    name: "Taxi Maria",
    slug: "taxi-maria",
    phone: "+41 79 234 56 78",
    whatsapp: "+41 79 234 56 78",
    email: "maria@eitaxi.ch",
    password: "demo123456",
    experience: 5,
    description: "Servicio de taxi en Ginebra y la zona francesa de Suiza. Vehículo confortable y conductoras profesional. Ideal para familias y viajeros de negocios.",
    isAvailable24h: true,
    services: ["airport", "city", "corporate"],
    routes: ["geneva-airport", "geneva-lausanne"],
    languages: ["fr", "en", "es"],
    serviceZones: ["Centro de la ciudad", "Aeropuerto"],
    vehicleType: "taxi",
    vehicleBrand: "BMW",
    vehicleModel: "5 Series",
    vehicleYear: 2021,
    vehicleColor: "Blanco",
    passengerCapacity: 4,
    subscription: "featured",
    isVerified: true,
    isTopRated: false,
    pricePerKm: 3.20,
    basePrice: 5.50,
  },
  {
    name: "Taxi Hans",
    slug: "taxi-hans",
    phone: "+41 79 345 67 89",
    whatsapp: "+41 79 345 67 89",
    email: "hans@eitaxi.ch",
    password: "demo123456",
    experience: 12,
    description: "El taxi más confiable de Berna. Conozco cada rincón de la ciudad y sus alrededores. Servicio puntual y profesional garantizado.",
    isAvailable24h: true,
    services: ["airport", "city", "long_distance"],
    routes: ["bern-airport", "bern-zurich", "bern-interlaken"],
    languages: ["de", "en", "fr"],
    serviceZones: ["Centro de la ciudad", "Área metropolitana"],
    vehicleType: "van",
    vehicleBrand: "Volkswagen",
    vehicleModel: "Multivan",
    vehicleYear: 2023,
    vehicleColor: "Plata",
    passengerCapacity: 8,
    subscription: "premium",
    isVerified: true,
    isTopRated: true,
    pricePerKm: 3.80,
    basePrice: 7.00,
  },
  {
    name: "Taxi Marco",
    slug: "taxi-marco",
    phone: "+41 79 456 78 90",
    whatsapp: "+41 79 456 78 90",
    email: "marco@eitaxi.ch",
    password: "demo123456",
    experience: 6,
    description: "Tu taxi en Ticino! Servicio profesional en Lugano y toda la región italoparlante de Suiza. Traslados a Milán y aeropuertos italianos.",
    isAvailable24h: true,
    services: ["airport", "city", "long_distance"],
    routes: ["lugano-milano", "lugano-airport"],
    languages: ["it", "de", "en"],
    serviceZones: ["Centro de la ciudad", "Aeropuerto"],
    vehicleType: "taxi",
    vehicleBrand: "Audi",
    vehicleModel: "A6",
    vehicleYear: 2020,
    vehicleColor: "Azul",
    passengerCapacity: 4,
    subscription: "free",
    isVerified: false,
    isTopRated: false,
    pricePerKm: 3.00,
    basePrice: 5.00,
  },
  {
    name: "Taxi Ahmed",
    slug: "taxi-ahmed",
    phone: "+41 79 567 89 01",
    whatsapp: "+41 79 567 89 01",
    email: "ahmed@eitaxi.ch",
    password: "demo123456",
    experience: 4,
    description: "Servicio de taxi en Basilea y la región trinacional (Suiza, Francia, Alemania). Multilingüe: alemán, francés, inglés y árabe.",
    isAvailable24h: true,
    services: ["airport", "city", "corporate"],
    routes: ["basel-airport", "basel-zurich"],
    languages: ["de", "fr", "en", "ar"],
    serviceZones: ["Centro de la ciudad", "Aeropuerto", "Estación de tren"],
    vehicleType: "taxi",
    vehicleBrand: "Skoda",
    vehicleModel: "Superb",
    vehicleYear: 2022,
    vehicleColor: "Gris",
    passengerCapacity: 4,
    subscription: "featured",
    isVerified: true,
    isTopRated: false,
    pricePerKm: 2.90,
    basePrice: 5.00,
  },
  {
    name: "Limousine Geneva",
    slug: "limousine-geneva",
    phone: "+41 79 678 90 12",
    whatsapp: "+41 79 678 90 12",
    email: "limousine@eitaxi.ch",
    password: "demo123456",
    experience: 10,
    description: "Servicio de limusina premium en Ginebra. Ideal para eventos corporativos, bodas y ocasiones especiales. Vehículos de lujo con chófer profesional.",
    isAvailable24h: true,
    services: ["limousine", "corporate", "events", "airport"],
    routes: ["geneva-airport", "geneva-lausanne"],
    languages: ["fr", "en", "de"],
    serviceZones: ["Centro de la ciudad", "Aeropuerto", "Zona empresarial"],
    vehicleType: "limousine",
    vehicleBrand: "Mercedes",
    vehicleModel: "S-Class",
    vehicleYear: 2024,
    vehicleColor: "Negro",
    passengerCapacity: 3,
    subscription: "premium",
    isVerified: true,
    isTopRated: true,
    hourlyRate: 120,
    basePrice: 50,
  },
]

// Rutas populares predefinidas con distancias
const popularRoutes = [
  { origin: "Zürich", destination: "Aeropuerto de Zürich", distance: 12, avgPrice: 50 },
  { origin: "Zürich", destination: "Bern", distance: 125, avgPrice: 280 },
  { origin: "Zürich", destination: "Basel", distance: 87, avgPrice: 200 },
  { origin: "Zürich", destination: "Lucerne", distance: 52, avgPrice: 120 },
  { origin: "Zürich", destination: "Geneva", distance: 278, avgPrice: 550 },
  { origin: "Geneva", destination: "Aeropuerto de Ginebra", distance: 6, avgPrice: 35 },
  { origin: "Geneva", destination: "Lausanne", distance: 62, avgPrice: 150 },
  { origin: "Geneva", destination: "Bern", distance: 160, avgPrice: 350 },
  { origin: "Bern", destination: "Interlaken", distance: 52, avgPrice: 130 },
  { origin: "Bern", destination: "Basel", distance: 100, avgPrice: 230 },
  { origin: "Basel", destination: "Aeropuerto de Basilea", distance: 10, avgPrice: 40 },
  { origin: "Lugano", destination: "Milano", distance: 80, avgPrice: 200 },
  { origin: "Lausanne", destination: "Montreux", distance: 30, avgPrice: 80 },
  { origin: "Zürich", destination: "St. Gallen", distance: 68, avgPrice: 160 },
  { origin: "Zürich", destination: "Winterthur", distance: 28, avgPrice: 70 },
  { origin: "Zermatt", destination: "Geneva", distance: 230, avgPrice: 480 },
  { origin: "Interlaken", destination: "Zürich", distance: 115, avgPrice: 260 },
]

async function main() {
  console.log("🌱 Iniciando seed de la base de datos EiTaxi...")

  // Crear cantones y ciudades
  for (const cantonData of swissData) {
    const canton = await prisma.canton.create({
      data: {
        name: cantonData.name,
        code: cantonData.code,
        slug: cantonData.slug,
        latitude: cantonData.latitude,
        longitude: cantonData.longitude,
        cities: {
          create: cantonData.cities.map(city => ({
            name: city.name,
            slug: city.slug,
            latitude: city.latitude,
            longitude: city.longitude,
            postalCode: city.postalCode,
          }))
        }
      },
      include: { cities: true }
    })
    console.log(`✅ Creado cantón: ${canton.name} con ${canton.cities.length} ciudades`)
  }

  // Crear lugares de interés
  for (const place of placesData) {
    await prisma.place.create({
      data: {
        name: place.name,
        type: place.type,
        slug: place.slug,
        latitude: place.latitude,
        longitude: place.longitude,
        isPopular: place.isPopular,
      }
    })
  }
  console.log(`✅ Creados ${placesData.length} lugares de interés`)

  // Crear taxistas de ejemplo
  const zurichCity = await prisma.city.findFirst({ where: { slug: "zurich" } })
  const zurichCanton = await prisma.canton.findFirst({ where: { slug: "zurich" } })
  const genevaCity = await prisma.city.findFirst({ where: { slug: "geneva" } })
  const genevaCanton = await prisma.canton.findFirst({ where: { slug: "geneva" } })
  const bernCity = await prisma.city.findFirst({ where: { slug: "bern" } })
  const bernCanton = await prisma.canton.findFirst({ where: { slug: "bern" } })
  const luganoCity = await prisma.city.findFirst({ where: { slug: "lugano" } })
  const ticinoCanton = await prisma.canton.findFirst({ where: { slug: "ticino" } })
  const baselCity = await prisma.city.findFirst({ where: { slug: "basel" } })
  const baselCanton = await prisma.canton.findFirst({ where: { slug: "basel-stadt" } })

  const createDriver = async (driverData: typeof sampleDrivers[0], cityId: string, cantonId: string) => {
    const { services, routes, languages, serviceZones, password, ...rest } = driverData
    const hashedPassword = await bcrypt.hash(password, 10)
    await prisma.taxiDriver.create({
      data: {
        ...rest,
        password: hashedPassword,
        cityId,
        cantonId,
        services: JSON.stringify(services),
        routes: JSON.stringify(routes),
        languages: JSON.stringify(languages),
        serviceZones: JSON.stringify(serviceZones),
      }
    })
    console.log(`✅ Creado conductor: ${driverData.name} (${driverData.email})`)
  }

  if (zurichCity && zurichCanton) {
    await createDriver(sampleDrivers[0], zurichCity.id, zurichCanton.id)
  }
  if (genevaCity && genevaCanton) {
    await createDriver(sampleDrivers[1], genevaCity.id, genevaCanton.id)
    await createDriver(sampleDrivers[5], genevaCity.id, genevaCanton.id)
  }
  if (bernCity && bernCanton) {
    await createDriver(sampleDrivers[2], bernCity.id, bernCanton.id)
  }
  if (luganoCity && ticinoCanton) {
    await createDriver(sampleDrivers[3], luganoCity.id, ticinoCanton.id)
  }
  if (baselCity && baselCanton) {
    await createDriver(sampleDrivers[4], baselCity.id, baselCanton.id)
  }

  // Crear rutas populares
  for (const route of popularRoutes) {
    await prisma.route.create({
      data: {
        origin: route.origin,
        destination: route.destination,
        slug: `${route.origin.toLowerCase().replace(/\s+/g, '-')}-${route.destination.toLowerCase().replace(/\s+/g, '-')}`,
        distance: route.distance,
        avgPrice: route.avgPrice,
        originLat: 0,
        originLng: 0,
        destLat: 0,
        destLng: 0,
      }
    })
  }
  console.log(`✅ Creadas ${popularRoutes.length} rutas populares`)

  console.log("🎉 Seed completado!")
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
