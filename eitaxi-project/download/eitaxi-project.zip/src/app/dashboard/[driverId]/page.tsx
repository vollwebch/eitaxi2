"use client";

import { useState, useEffect, useRef } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  Car,
  User,
  Phone,
  MessageCircle,
  MapPin,
  Clock,
  Check,
  Star,
  Building2,
  Route,
  Plane,
  Shield,
  Upload,
  X,
  Globe,
  Users,
  Eye,
  DollarSign,
  Plus,
  Trash2,
  Instagram,
  Facebook,
  Link as LinkIcon,
  Edit3,
  BarChart3,
  Settings,
  Save,
  Loader2,
  ArrowLeft,
  Calendar,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";

// Types
interface City {
  id: string;
  name: string;
  slug: string;
}

interface Canton {
  id: string;
  name: string;
  code: string;
  slug: string;
}

interface DriverRoute {
  id?: string;
  origin: string;
  destination: string;
  price?: number | null;
}

interface Schedule {
  id?: string;
  dayOfWeek: number;
  startTime: string;
  endTime: string;
  isActive: boolean;
}

interface Driver {
  id: string;
  name: string;
  slug: string;
  phone: string;
  whatsapp: string | null;
  email: string | null;
  description: string | null;
  imageUrl: string | null;
  experience: number;
  vehicleType: string;
  vehicleBrand: string | null;
  vehicleModel: string | null;
  vehicleYear: number | null;
  vehicleColor: string | null;
  passengerCapacity: number | null;
  isAvailable24h: boolean;
  isVerified: boolean;
  isTopRated: boolean;
  rating: number;
  reviewCount: number;
  views: number;
  contacts: number;
  services: string[];
  languages: string[];
  serviceZones: string[];
  basePrice: number | null;
  pricePerKm: number | null;
  hourlyRate: number | null;
  website: string | null;
  instagram: string | null;
  facebook: string | null;
  city: City;
  canton: Canton;
  driverRoutes: DriverRoute[];
  schedules: Schedule[];
}

// Constants
const vehicleTypes = [
  { id: "taxi", label: "Taxi", icon: "🚕" },
  { id: "limousine", label: "Limusina", icon: "🚗" },
  { id: "van", label: "Van / Minibus", icon: "🚐" },
  { id: "premium", label: "Premium", icon: "✨" },
];

const serviceOptions = [
  { id: "airport", label: "Aeropuerto", icon: Plane },
  { id: "city", label: "Ciudad", icon: Building2 },
  { id: "long_distance", label: "Larga distancia", icon: Route },
  { id: "limousine", label: "Limusina", icon: Car },
  { id: "corporate", label: "Corporativo", icon: Shield },
  { id: "events", label: "Eventos", icon: Star },
  { id: "delivery", label: "Entregas", icon: Route },
  { id: "night", label: "Nocturno", icon: Clock },
];

const languageOptions = [
  { id: "de", label: "Alemán", flag: "🇩🇪" },
  { id: "en", label: "Inglés", flag: "🇬🇧" },
  { id: "fr", label: "Francés", flag: "🇫🇷" },
  { id: "it", label: "Italiano", flag: "🇮🇹" },
  { id: "es", label: "Español", flag: "🇪🇸" },
  { id: "pt", label: "Portugués", flag: "🇵🇹" },
  { id: "ru", label: "Ruso", flag: "🇷🇺" },
  { id: "zh", label: "Chino", flag: "🇨🇳" },
];

const popularZones = [
  "Centro de la ciudad",
  "Aeropuerto",
  "Estación de tren",
  "Zona empresarial",
  "Área metropolitana",
  "Zona turística",
];

const daysOfWeek = [
  { value: 1, label: "Lunes" },
  { value: 2, label: "Martes" },
  { value: 3, label: "Miércoles" },
  { value: 4, label: "Jueves" },
  { value: 5, label: "Viernes" },
  { value: 6, label: "Sábado" },
  { value: 0, label: "Domingo" },
];

export default function DriverDashboardPage() {
  const params = useParams();
  const router = useRouter();
  const driverId = params.driverId as string;

  // State
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [driver, setDriver] = useState<Driver | null>(null);

  // Form state
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    whatsapp: "",
    email: "",
    address: "",
    experience: 1,
    description: "",
    vehicleType: "taxi",
    vehicleBrand: "",
    vehicleModel: "",
    vehicleYear: undefined as number | undefined,
    vehicleColor: "",
    passengerCapacity: undefined as number | undefined,
    isAvailable24h: true,
    services: [] as string[],
    languages: [] as string[],
    serviceZones: [] as string[],
    basePrice: undefined as number | undefined,
    pricePerKm: undefined as number | undefined,
    hourlyRate: undefined as number | undefined,
    website: "",
    instagram: "",
    facebook: "",
  });

  const [routes, setRoutes] = useState<DriverRoute[]>([]);
  const [newRoute, setNewRoute] = useState<DriverRoute>({ origin: "", destination: "", price: undefined });
  const [schedules, setSchedules] = useState<Schedule[]>([]);

  // Image state
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Fetch driver data
  useEffect(() => {
    const fetchDriver = async () => {
      try {
        const res = await fetch(`/api/drivers?id=${driverId}`);
        const data = await res.json();

        if (data.success) {
          setDriver(data.data);
          // Initialize form data
          setFormData({
            name: data.data.name || "",
            phone: data.data.phone || "",
            whatsapp: data.data.whatsapp || "",
            email: data.data.email || "",
            address: data.data.address || "",
            experience: data.data.experience || 1,
            description: data.data.description || "",
            vehicleType: data.data.vehicleType || "taxi",
            vehicleBrand: data.data.vehicleBrand || "",
            vehicleModel: data.data.vehicleModel || "",
            vehicleYear: data.data.vehicleYear || undefined,
            vehicleColor: data.data.vehicleColor || "",
            passengerCapacity: data.data.passengerCapacity || undefined,
            isAvailable24h: data.data.isAvailable24h ?? true,
            services: data.data.services || [],
            languages: data.data.languages || [],
            serviceZones: data.data.serviceZones || [],
            basePrice: data.data.basePrice || undefined,
            pricePerKm: data.data.pricePerKm || undefined,
            hourlyRate: data.data.hourlyRate || undefined,
            website: data.data.website || "",
            instagram: data.data.instagram || "",
            facebook: data.data.facebook || "",
          });
          setRoutes(data.data.driverRoutes || []);
          setSchedules(data.data.schedules || daysOfWeek.map(day => ({
            dayOfWeek: day.value,
            startTime: "09:00",
            endTime: "18:00",
            isActive: day.value >= 1 && day.value <= 5,
          })));
          setImagePreview(data.data.imageUrl || null);
        } else {
          setError(data.error || "Conductor no encontrado");
        }
      } catch (err) {
        setError("Error al cargar los datos");
      } finally {
        setLoading(false);
      }
    };

    if (driverId) {
      fetchDriver();
    }
  }, [driverId]);

  // Handle image upload
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        setError("La imagen no puede superar los 5MB");
        return;
      }
      setImageFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Toggle functions
  const toggleService = (serviceId: string) => {
    setFormData(prev => ({
      ...prev,
      services: prev.services.includes(serviceId)
        ? prev.services.filter(s => s !== serviceId)
        : [...prev.services, serviceId],
    }));
  };

  const toggleLanguage = (langId: string) => {
    setFormData(prev => ({
      ...prev,
      languages: prev.languages.includes(langId)
        ? prev.languages.filter(l => l !== langId)
        : [...prev.languages, langId],
    }));
  };

  const toggleZone = (zone: string) => {
    setFormData(prev => ({
      ...prev,
      serviceZones: prev.serviceZones.includes(zone)
        ? prev.serviceZones.filter(z => z !== zone)
        : [...prev.serviceZones, zone],
    }));
  };

  // Route functions
  const addRoute = () => {
    if (newRoute.origin && newRoute.destination) {
      setRoutes([...routes, newRoute]);
      setNewRoute({ origin: "", destination: "", price: undefined });
    }
  };

  const removeRoute = (index: number) => {
    setRoutes(routes.filter((_, i) => i !== index));
  };

  // Schedule functions
  const toggleSchedule = (dayOfWeek: number) => {
    setSchedules(schedules.map(s => 
      s.dayOfWeek === dayOfWeek ? { ...s, isActive: !s.isActive } : s
    ));
  };

  const updateScheduleTime = (dayOfWeek: number, field: 'startTime' | 'endTime', value: string) => {
    setSchedules(schedules.map(s => 
      s.dayOfWeek === dayOfWeek ? { ...s, [field]: value } : s
    ));
  };

  // Save changes
  const handleSave = async () => {
    setSaving(true);
    setError(null);
    setSuccess(null);

    try {
      // Upload image if changed
      let imageUrl = driver?.imageUrl;
      if (imageFile) {
        const formDataImg = new FormData();
        formDataImg.append("file", imageFile);
        
        const uploadRes = await fetch("/api/upload", {
          method: "POST",
          body: formDataImg,
        });
        const uploadData = await uploadRes.json();
        if (uploadData.success) {
          imageUrl = uploadData.url;
        }
      }

      const response = await fetch("/api/drivers", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: driverId,
          ...formData,
          imageUrl,
          routes,
          schedules: formData.isAvailable24h ? null : schedules.filter(s => s.isActive),
        }),
      });

      const data = await response.json();

      if (data.success) {
        setDriver(data.data);
        setSuccess("Perfil actualizado correctamente");
        setTimeout(() => setSuccess(null), 3000);
      } else {
        setError(data.error || "Error al actualizar el perfil");
      }
    } catch (err) {
      setError("Error de conexión. Intenta de nuevo.");
    } finally {
      setSaving(false);
    }
  };

  // Loading state
  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-12 w-12 animate-spin text-yellow-400 mx-auto mb-4" />
          <p className="text-muted-foreground">Cargando panel...</p>
        </div>
      </div>
    );
  }

  // Error state
  if (error && !driver) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="max-w-md w-full p-8 text-center border-border">
          <Car className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
          <h1 className="text-2xl font-bold mb-2">Panel no encontrado</h1>
          <p className="text-muted-foreground mb-6">{error}</p>
          <Link href="/">
            <Button className="bg-yellow-400 text-black hover:bg-yellow-500">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Volver al inicio
            </Button>
          </Link>
        </Card>
      </div>
    );
  }

  const publicUrl = driver ? `/${driver.canton.slug}/${driver.city.slug}/${driver.slug}` : "";

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur-xl">
        <div className="container mx-auto px-4">
          <div className="flex h-16 items-center justify-between">
            {/* Logo */}
            <Link href="/" className="flex items-center gap-2">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-yellow-400 to-yellow-500">
                <Car className="h-6 w-6 text-black" />
              </div>
              <span className="text-xl font-bold">
                <span className="text-yellow-400">Taxi</span>
                <span className="text-white">Zone</span>
              </span>
            </Link>

            {/* Actions */}
            <div className="flex items-center gap-3">
              <Link href={publicUrl} target="_blank">
                <Button variant="outline" size="sm">
                  <Eye className="mr-2 h-4 w-4" />
                  Ver perfil público
                </Button>
              </Link>
              <Button
                className="bg-yellow-400 text-black hover:bg-yellow-500"
                onClick={handleSave}
                disabled={saving}
              >
                {saving ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Guardando...
                  </>
                ) : (
                  <>
                    <Save className="mr-2 h-4 w-4" />
                    Guardar cambios
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main content */}
      <main className="container mx-auto px-4 py-8">
        {/* Success/Error messages */}
        {success && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6 p-4 bg-green-500/10 border border-green-500/30 rounded-lg text-green-500"
          >
            {success}
          </motion.div>
        )}
        {error && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6 p-4 bg-destructive/10 border border-destructive/30 rounded-lg text-destructive"
          >
            {error}
          </motion.div>
        )}

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <Card className="border-border bg-card">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-yellow-400/10 flex items-center justify-center">
                  <Eye className="h-5 w-5 text-yellow-400" />
                </div>
                <div>
                  <div className="text-2xl font-bold">{driver?.views || 0}</div>
                  <div className="text-xs text-muted-foreground">Vistas del perfil</div>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="border-border bg-card">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-green-400/10 flex items-center justify-center">
                  <Phone className="h-5 w-5 text-green-400" />
                </div>
                <div>
                  <div className="text-2xl font-bold">{driver?.contacts || 0}</div>
                  <div className="text-xs text-muted-foreground">Contactos</div>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="border-border bg-card">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-blue-400/10 flex items-center justify-center">
                  <Star className="h-5 w-5 text-blue-400" />
                </div>
                <div>
                  <div className="text-2xl font-bold">{driver?.rating.toFixed(1) || "5.0"}</div>
                  <div className="text-xs text-muted-foreground">Valoración</div>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="border-border bg-card">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-lg bg-purple-400/10 flex items-center justify-center">
                  <Calendar className="h-5 w-5 text-purple-400" />
                </div>
                <div>
                  <div className="text-2xl font-bold">{driver?.experience || 0}</div>
                  <div className="text-xs text-muted-foreground">Años experiencia</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Profile completion */}
        <Card className="border-border bg-card mb-8">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="font-medium">Completitud del perfil</span>
              <span className="text-yellow-400 font-medium">
                {Math.round(
                  ([
                    formData.name,
                    formData.phone,
                    formData.description,
                    imagePreview,
                    formData.vehicleBrand,
                    formData.services.length > 0,
                    formData.languages.length > 0,
                    routes.length > 0,
                  ].filter(Boolean).length / 8) * 100
                )}%
              </span>
            </div>
            <Progress
              value={Math.round(
                ([
                  formData.name,
                  formData.phone,
                  formData.description,
                  imagePreview,
                  formData.vehicleBrand,
                  formData.services.length > 0,
                  formData.languages.length > 0,
                  routes.length > 0,
                ].filter(Boolean).length / 8) * 100
              )}
              className="h-2"
            />
          </CardContent>
        </Card>

        {/* Public URL */}
        <Card className="border-yellow-400/30 bg-yellow-400/5 mb-8">
          <CardContent className="p-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="font-medium mb-1">Tu URL pública</h3>
                <code className="text-yellow-400 text-sm">
                  eitaxi.ch{publicUrl}
                </code>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => navigator.clipboard.writeText(`https://eitaxi.ch${publicUrl}`)}
              >
                Copiar enlace
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Tabs */}
        <Tabs defaultValue="basic" className="space-y-6">
          <TabsList className="grid grid-cols-2 md:grid-cols-5 w-full">
            <TabsTrigger value="basic">
              <User className="mr-2 h-4 w-4" />
              Datos básicos
            </TabsTrigger>
            <TabsTrigger value="vehicle">
              <Car className="mr-2 h-4 w-4" />
              Vehículo
            </TabsTrigger>
            <TabsTrigger value="services">
              <Star className="mr-2 h-4 w-4" />
              Servicios
            </TabsTrigger>
            <TabsTrigger value="prices">
              <DollarSign className="mr-2 h-4 w-4" />
              Precios
            </TabsTrigger>
            <TabsTrigger value="schedule">
              <Clock className="mr-2 h-4 w-4" />
              Horarios
            </TabsTrigger>
          </TabsList>

          {/* Basic Info Tab */}
          <TabsContent value="basic">
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5 text-yellow-400" />
                  Información básica
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Photo */}
                <div>
                  <Label>Foto de perfil</Label>
                  <div className="flex items-center gap-4 mt-2">
                    {imagePreview ? (
                      <div className="relative">
                        <img
                          src={imagePreview}
                          alt="Profile"
                          className="w-24 h-24 object-cover rounded-lg border border-border"
                        />
                        <Button
                          type="button"
                          variant="destructive"
                          size="icon"
                          className="absolute -top-2 -right-2 h-6 w-6"
                          onClick={() => {
                            setImageFile(null);
                            setImagePreview(null);
                          }}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    ) : (
                      <div
                        onClick={() => fileInputRef.current?.click()}
                        className="w-24 h-24 border-2 border-dashed border-border rounded-lg flex flex-col items-center justify-center cursor-pointer hover:border-yellow-400 hover:bg-yellow-400/5 transition-all"
                      >
                        <Upload className="h-6 w-6 text-muted-foreground" />
                      </div>
                    )}
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="hidden"
                    />
                    <div className="text-sm text-muted-foreground">
                      <p>JPG, PNG. Máximo 5MB</p>
                      <p>Recomendado: 400x400px</p>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name">Nombre *</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="mt-1.5"
                    />
                  </div>
                  <div>
                    <Label htmlFor="experience">Años de experiencia</Label>
                    <Input
                      id="experience"
                      type="number"
                      min={0}
                      value={formData.experience}
                      onChange={(e) => setFormData({ ...formData, experience: parseInt(e.target.value) || 0 })}
                      className="mt-1.5"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="phone">Teléfono *</Label>
                    <Input
                      id="phone"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="mt-1.5"
                    />
                  </div>
                  <div>
                    <Label htmlFor="whatsapp">WhatsApp</Label>
                    <Input
                      id="whatsapp"
                      value={formData.whatsapp || ""}
                      onChange={(e) => setFormData({ ...formData, whatsapp: e.target.value })}
                      className="mt-1.5"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email || ""}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="mt-1.5"
                  />
                </div>

                <div>
                  <Label htmlFor="description">Descripción</Label>
                  <Textarea
                    id="description"
                    value={formData.description || ""}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    className="mt-1.5 min-h-[120px]"
                    placeholder="Cuéntanos sobre tu servicio..."
                  />
                </div>

                <Separator />

                {/* Social Media */}
                <h3 className="font-medium flex items-center gap-2">
                  <Globe className="h-4 w-4 text-yellow-400" />
                  Redes sociales
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="website">Sitio web</Label>
                    <div className="relative mt-1.5">
                      <LinkIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        id="website"
                        value={formData.website || ""}
                        onChange={(e) => setFormData({ ...formData, website: e.target.value })}
                        className="pl-10"
                        placeholder="https://..."
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="instagram">Instagram</Label>
                    <div className="relative mt-1.5">
                      <Instagram className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        id="instagram"
                        value={formData.instagram || ""}
                        onChange={(e) => setFormData({ ...formData, instagram: e.target.value })}
                        className="pl-10"
                        placeholder="@usuario"
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="facebook">Facebook</Label>
                    <div className="relative mt-1.5">
                      <Facebook className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        id="facebook"
                        value={formData.facebook || ""}
                        onChange={(e) => setFormData({ ...formData, facebook: e.target.value })}
                        className="pl-10"
                        placeholder="pagina"
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Vehicle Tab */}
          <TabsContent value="vehicle">
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Car className="h-5 w-5 text-yellow-400" />
                  Información del vehículo
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <Label>Tipo de vehículo principal</Label>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-2">
                    {vehicleTypes.map((type) => {
                      const isSelected = formData.vehicleType === type.id;
                      return (
                        <button
                          key={type.id}
                          type="button"
                          onClick={() => setFormData({ ...formData, vehicleType: type.id })}
                          className={`p-4 rounded-lg border text-center transition-all ${
                            isSelected
                              ? "border-yellow-400 bg-yellow-400/10"
                              : "border-border hover:border-yellow-400/50"
                          }`}
                        >
                          <div className="text-2xl mb-1">{type.icon}</div>
                          <div className="font-medium">{type.label}</div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="vehicleBrand">Marca</Label>
                    <Input
                      id="vehicleBrand"
                      value={formData.vehicleBrand || ""}
                      onChange={(e) => setFormData({ ...formData, vehicleBrand: e.target.value })}
                      className="mt-1.5"
                      placeholder="Ej: Mercedes"
                    />
                  </div>
                  <div>
                    <Label htmlFor="vehicleModel">Modelo</Label>
                    <Input
                      id="vehicleModel"
                      value={formData.vehicleModel || ""}
                      onChange={(e) => setFormData({ ...formData, vehicleModel: e.target.value })}
                      className="mt-1.5"
                      placeholder="Ej: E-Class"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="vehicleYear">Año</Label>
                    <Input
                      id="vehicleYear"
                      type="number"
                      value={formData.vehicleYear || ""}
                      onChange={(e) => setFormData({ ...formData, vehicleYear: parseInt(e.target.value) || undefined })}
                      className="mt-1.5"
                    />
                  </div>
                  <div>
                    <Label htmlFor="vehicleColor">Color</Label>
                    <Input
                      id="vehicleColor"
                      value={formData.vehicleColor || ""}
                      onChange={(e) => setFormData({ ...formData, vehicleColor: e.target.value })}
                      className="mt-1.5"
                    />
                  </div>
                  <div>
                    <Label htmlFor="passengerCapacity">Pasajeros</Label>
                    <Input
                      id="passengerCapacity"
                      type="number"
                      min={1}
                      max={16}
                      value={formData.passengerCapacity || ""}
                      onChange={(e) => setFormData({ ...formData, passengerCapacity: parseInt(e.target.value) || undefined })}
                      className="mt-1.5"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Services Tab */}
          <TabsContent value="services">
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Star className="h-5 w-5 text-yellow-400" />
                  Servicios e idiomas
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <Label>Servicios que ofreces</Label>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-2">
                    {serviceOptions.map((service) => {
                      const isSelected = formData.services.includes(service.id);
                      const Icon = service.icon;
                      return (
                        <button
                          key={service.id}
                          type="button"
                          onClick={() => toggleService(service.id)}
                          className={`p-4 rounded-lg border text-left transition-all ${
                            isSelected
                              ? "border-yellow-400 bg-yellow-400/10"
                              : "border-border hover:border-yellow-400/50"
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            <Icon className={`h-5 w-5 ${isSelected ? "text-yellow-400" : "text-muted-foreground"}`} />
                            <span className="font-medium">{service.label}</span>
                            {isSelected && <Check className="h-4 w-4 text-yellow-400 ml-auto" />}
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <Separator />

                <div>
                  <Label>Idiomas que hablas</Label>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {languageOptions.map((lang) => {
                      const isSelected = formData.languages.includes(lang.id);
                      return (
                        <Badge
                          key={lang.id}
                          variant={isSelected ? "default" : "outline"}
                          className={`cursor-pointer transition-all ${
                            isSelected
                              ? "bg-yellow-400 text-black hover:bg-yellow-500"
                              : "hover:bg-muted"
                          }`}
                          onClick={() => toggleLanguage(lang.id)}
                        >
                          <span className="mr-1.5">{lang.flag}</span>
                          {lang.label}
                          {isSelected && <Check className="ml-1 h-3 w-3" />}
                        </Badge>
                      );
                    })}
                  </div>
                </div>

                <Separator />

                <div>
                  <Label>Zonas de servicio</Label>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {popularZones.map((zone) => {
                      const isSelected = formData.serviceZones.includes(zone);
                      return (
                        <Badge
                          key={zone}
                          variant={isSelected ? "default" : "outline"}
                          className={`cursor-pointer transition-all ${
                            isSelected
                              ? "bg-yellow-400 text-black hover:bg-yellow-500"
                              : "hover:bg-muted"
                          }`}
                          onClick={() => toggleZone(zone)}
                        >
                          {zone}
                          {isSelected && <Check className="ml-1 h-3 w-3" />}
                        </Badge>
                      );
                    })}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Prices Tab */}
          <TabsContent value="prices">
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5 text-yellow-400" />
                  Precios y tarifas
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Base prices */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="basePrice">Precio base (CHF)</Label>
                    <Input
                      id="basePrice"
                      type="number"
                      min={0}
                      value={formData.basePrice || ""}
                      onChange={(e) => setFormData({ ...formData, basePrice: parseFloat(e.target.value) || undefined })}
                      className="mt-1.5"
                      placeholder="Ej: 5"
                    />
                    <p className="text-xs text-muted-foreground mt-1">Tarifa inicial</p>
                  </div>
                  <div>
                    <Label htmlFor="pricePerKm">Precio por km (CHF)</Label>
                    <Input
                      id="pricePerKm"
                      type="number"
                      min={0}
                      step="0.1"
                      value={formData.pricePerKm || ""}
                      onChange={(e) => setFormData({ ...formData, pricePerKm: parseFloat(e.target.value) || undefined })}
                      className="mt-1.5"
                      placeholder="Ej: 2.50"
                    />
                    <p className="text-xs text-muted-foreground mt-1">Por kilómetro</p>
                  </div>
                  <div>
                    <Label htmlFor="hourlyRate">Tarifa hora (CHF)</Label>
                    <Input
                      id="hourlyRate"
                      type="number"
                      min={0}
                      value={formData.hourlyRate || ""}
                      onChange={(e) => setFormData({ ...formData, hourlyRate: parseFloat(e.target.value) || undefined })}
                      className="mt-1.5"
                      placeholder="Ej: 60"
                    />
                    <p className="text-xs text-muted-foreground mt-1">Para limusinas</p>
                  </div>
                </div>

                <Separator />

                {/* Specific Routes */}
                <div>
                  <Label className="flex items-center gap-2">
                    <Route className="h-4 w-4" />
                    Rutas con precio fijo
                  </Label>
                  <p className="text-sm text-muted-foreground mb-3">
                    Añade rutas populares con precios fijos
                  </p>

                  {/* Add new route */}
                  <div className="flex flex-col md:flex-row gap-2 mb-4">
                    <Input
                      placeholder="Origen"
                      value={newRoute.origin}
                      onChange={(e) => setNewRoute({ ...newRoute, origin: e.target.value })}
                      className="flex-1"
                    />
                    <Input
                      placeholder="Destino"
                      value={newRoute.destination}
                      onChange={(e) => setNewRoute({ ...newRoute, destination: e.target.value })}
                      className="flex-1"
                    />
                    <Input
                      type="number"
                      placeholder="Precio CHF"
                      value={newRoute.price || ""}
                      onChange={(e) => setNewRoute({ ...newRoute, price: parseFloat(e.target.value) || undefined })}
                      className="w-32"
                    />
                    <Button
                      type="button"
                      variant="outline"
                      onClick={addRoute}
                      disabled={!newRoute.origin || !newRoute.destination}
                    >
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>

                  {/* List of routes */}
                  {routes.length > 0 && (
                    <div className="space-y-2 max-h-64 overflow-y-auto">
                      {routes.map((route, index) => (
                        <div
                          key={index}
                          className="flex items-center justify-between p-3 rounded-lg bg-muted/50 border border-border"
                        >
                          <div>
                            <span className="font-medium">{route.origin}</span>
                            <span className="mx-2 text-muted-foreground">→</span>
                            <span className="font-medium">{route.destination}</span>
                          </div>
                          <div className="flex items-center gap-3">
                            {route.price && (
                              <span className="text-yellow-400 font-medium">
                                CHF {route.price}
                              </span>
                            )}
                            <Button
                              type="button"
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 text-destructive hover:text-destructive"
                              onClick={() => removeRoute(index)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Schedule Tab */}
          <TabsContent value="schedule">
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-yellow-400" />
                  Horarios de disponibilidad
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* 24/7 toggle */}
                <div className="flex items-center space-x-2 p-4 rounded-lg bg-green-500/10 border border-green-500/30">
                  <Checkbox
                    id="available24h"
                    checked={formData.isAvailable24h}
                    onCheckedChange={(checked) =>
                      setFormData({
                        ...formData,
                        isAvailable24h: checked as boolean,
                      })
                    }
                  />
                  <Label
                    htmlFor="available24h"
                    className="text-sm cursor-pointer flex items-center gap-2"
                  >
                    <Clock className="h-4 w-4 text-green-500" />
                    <span className="font-medium text-green-500">
                      Disponible 24 horas, 7 días
                    </span>
                  </Label>
                </div>

                {/* Custom schedules */}
                {!formData.isAvailable24h && (
                  <div className="space-y-3">
                    <p className="text-sm text-muted-foreground">
                      Define tus horarios de disponibilidad
                    </p>
                    {daysOfWeek.map((day) => {
                      const schedule = schedules.find(s => s.dayOfWeek === day.value);
                      if (!schedule) return null;
                      
                      return (
                        <div
                          key={day.value}
                          className={`flex flex-col md:flex-row md:items-center gap-3 p-3 rounded-lg border transition-all ${
                            schedule.isActive
                              ? "border-yellow-400/50 bg-yellow-400/5"
                              : "border-border bg-muted/30 opacity-60"
                          }`}
                        >
                          <div className="flex items-center gap-3 w-full md:w-32">
                            <Checkbox
                              checked={schedule.isActive}
                              onCheckedChange={() => toggleSchedule(day.value)}
                            />
                            <span className="font-medium">{day.label}</span>
                          </div>
                          {schedule.isActive && (
                            <div className="flex items-center gap-2 flex-1">
                              <Input
                                type="time"
                                value={schedule.startTime}
                                onChange={(e) => updateScheduleTime(day.value, 'startTime', e.target.value)}
                                className="w-28"
                              />
                              <span className="text-muted-foreground">a</span>
                              <Input
                                type="time"
                                value={schedule.endTime}
                                onChange={(e) => updateScheduleTime(day.value, 'endTime', e.target.value)}
                                className="w-28"
                              />
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Save button fixed at bottom on mobile */}
        <div className="fixed bottom-0 left-0 right-0 p-4 bg-background/95 backdrop-blur-xl border-t border-border md:hidden z-50">
          <Button
            className="w-full bg-yellow-400 text-black hover:bg-yellow-500"
            onClick={handleSave}
            disabled={saving}
          >
            {saving ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Guardando...
              </>
            ) : (
              <>
                <Save className="mr-2 h-4 w-4" />
                Guardar cambios
              </>
            )}
          </Button>
        </div>
      </main>
    </div>
  );
}
