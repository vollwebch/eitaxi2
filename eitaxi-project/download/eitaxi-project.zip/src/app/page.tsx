"use client";

import { useState, useEffect, useRef } from "react";
import Link from "next/link";
import {
  Search,
  Phone,
  MessageCircle,
  MapPin,
  Clock,
  Star,
  CheckCircle,
  Award,
  ChevronDown,
  Car,
  Menu,
  ArrowRight,
  Shield,
  Zap,
  Users,
  Route,
  Plane,
  Building2,
  Calendar,
  Loader2,
  Navigation,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent } from "@/components/ui/sheet";

// Types
interface City {
  id: string;
  name: string;
  slug: string;
}

interface Canton {
  id: string;
  name: string;
  code: string;
  slug: string;
  cities: City[];
  _count?: { drivers: number };
}

interface TaxiDriver {
  id: string;
  name: string;
  slug: string;
  phone: string;
  whatsapp: string | null;
  experience: number;
  description: string | null;
  imageUrl: string | null;
  vehicleType: string;
  vehicleBrand: string | null;
  vehicleModel: string | null;
  isAvailable24h: boolean;
  services: string[];
  languages: string[];
  subscription: string;
  isVerified: boolean;
  isTopRated: boolean;
  rating: number;
  city: City;
  canton: Canton;
}

interface LocationSuggestion {
  id: string;
  name: string;
  type: 'city' | 'canton' | 'place';
  cantonName?: string;
  distance?: number;
  latitude: number;
  longitude: number;
}

// Service config
const serviceConfig: Record<string, { icon: typeof Car; label: string }> = {
  airport: { icon: Plane, label: "Aeropuerto" },
  city: { icon: Building2, label: "Ciudad" },
  long_distance: { icon: Route, label: "Larga distancia" },
  limousine: { icon: Car, label: "Limusina" },
  corporate: { icon: Shield, label: "Corporativo" },
  events: { icon: Calendar, label: "Eventos" },
};

// Vehicle type config
const vehicleTypeConfig: Record<string, { label: string; icon: string }> = {
  taxi: { label: "Taxi", icon: "🚕" },
  limousine: { label: "Limusina", icon: "🚗" },
  van: { label: "Van", icon: "🚐" },
  premium: { label: "Premium", icon: "✨" },
};

// Header Component
function Header({
  cantons,
  onCantonSelect,
  onMobileMenuOpen,
}: {
  cantons: Canton[];
  onCantonSelect: (canton: Canton) => void;
  onMobileMenuOpen: () => void;
}) {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur-xl">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-yellow-400 to-yellow-500">
              <Car className="h-6 w-6 text-black" />
            </div>
            <span className="text-xl font-bold">
              <span className="text-yellow-400">Ei</span>
              <span className="text-white">Taxi</span>
            </span>
          </Link>

          <nav className="hidden md:flex items-center gap-6">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="gap-1">
                  Cantones <ChevronDown className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-56 max-h-80 overflow-y-auto">
                {cantons.length > 0 ? cantons.map((canton) => (
                  <DropdownMenuItem
                    key={canton.id}
                    onClick={() => onCantonSelect(canton)}
                    className="flex items-center justify-between"
                  >
                    <span>{canton.name}</span>
                    <Badge variant="secondary" className="text-xs">
                      {canton._count?.drivers || 0}
                    </Badge>
                  </DropdownMenuItem>
                )) : (
                  <DropdownMenuItem disabled>Cargando...</DropdownMenuItem>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          </nav>

          <div className="flex items-center gap-3">
            <Link href="/login" className="hidden sm:block">
              <Button variant="ghost" size="sm">
                Acceder
              </Button>
            </Link>
            <Link href="/registrarse">
              <Button
                variant="outline"
                className="hidden sm:flex border-yellow-400 text-yellow-400 hover:bg-yellow-400 hover:text-black"
              >
                <Car className="mr-2 h-4 w-4" />
                Ser conductor
              </Button>
            </Link>
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={onMobileMenuOpen}
            >
              <Menu className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}

// Hero Section with Intelligent Autocomplete
function HeroSection({ 
  onSearch, 
  onSuggestionSelect 
}: { 
  onSearch: (query: string) => void;
  onSuggestionSelect: (suggestion: LocationSuggestion) => void;
}) {
  const [searchQuery, setSearchQuery] = useState("");
  const [suggestions, setSuggestions] = useState<LocationSuggestion[]>([]);
  const [showDropdown, setShowDropdown] = useState(false);
  const [loading, setLoading] = useState(false);
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const searchRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Get user location on mount
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          });
        },
        () => {
          // User denied location or error
          console.log("Location not available");
        }
      );
    }
  }, []);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setShowDropdown(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Debounce search
  useEffect(() => {
    const timeoutId = setTimeout(async () => {
      if (searchQuery.trim().length >= 1) {
        setLoading(true);
        try {
          let url = `/api/locations?q=${encodeURIComponent(searchQuery.trim())}`;
          if (userLocation) {
            url += `&lat=${userLocation.lat}&lng=${userLocation.lng}`;
          }
          const res = await fetch(url);
          const data = await res.json();
          if (data.success) {
            setSuggestions(data.data.suggestions);
            setShowDropdown(true);
          }
        } catch (error) {
          console.error("Error fetching suggestions:", error);
        } finally {
          setLoading(false);
        }
      } else {
        setSuggestions([]);
        setShowDropdown(false);
      }
    }, 200);

    return () => clearTimeout(timeoutId);
  }, [searchQuery, userLocation]);

  const handleSelectSuggestion = (suggestion: LocationSuggestion) => {
    setSearchQuery(suggestion.name);
    setShowDropdown(false);
    onSuggestionSelect(suggestion);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && searchQuery.trim()) {
      setShowDropdown(false);
      onSearch(searchQuery.trim());
    }
    if (e.key === 'Escape') {
      setShowDropdown(false);
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'city':
        return <Building2 className="h-4 w-4 text-muted-foreground" />;
      case 'canton':
        return <MapPin className="h-4 w-4 text-muted-foreground" />;
      case 'place':
        return <Navigation className="h-4 w-4 text-muted-foreground" />;
      default:
        return <MapPin className="h-4 w-4 text-muted-foreground" />;
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'city':
        return 'Ciudad';
      case 'canton':
        return 'Cantón';
      case 'place':
        return 'Lugar';
      default:
        return '';
    }
  };
  
  return (
    <section className="relative overflow-hidden py-16 md:py-24">
      <div className="absolute inset-0 bg-gradient-to-br from-yellow-400/5 via-transparent to-yellow-400/10" />
      
      <div className="container relative mx-auto px-4">
        <div className="mx-auto max-w-4xl text-center">
          <Badge
            variant="outline"
            className="mb-6 border-yellow-400/30 bg-yellow-400/10 text-yellow-400"
          >
            <Zap className="mr-1 h-3 w-3" />
            Conecta con conductores verificados en segundos
          </Badge>

          <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
            Tu taxi en <span className="text-yellow-400">Suiza</span>
            <br />
            a un clic de distancia
          </h1>

          <p className="text-lg md:text-xl text-gray-400 mb-10 max-w-2xl mx-auto">
            Encuentra taxistas profesionales, verificados y disponibles 24/7.
            Traslados al aeropuerto, ciudad, larga distancia y limusinas.
          </p>

          {/* Search Bar with Autocomplete */}
          <div className="max-w-xl mx-auto mb-8" ref={searchRef}>
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground z-10" />
              <Input
                ref={inputRef}
                type="text"
                placeholder="Busca por ciudad, cantón o zona..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={handleKeyDown}
                onFocus={() => suggestions.length > 0 && setShowDropdown(true)}
                className="pl-12 pr-4 h-14 text-lg bg-card border-border focus:border-yellow-400 focus:ring-yellow-400/20"
              />
              {loading && (
                <Loader2 className="absolute right-16 top-1/2 -translate-y-1/2 h-5 w-5 animate-spin text-muted-foreground" />
              )}
              <Button
                className="absolute right-2 top-1/2 -translate-y-1/2 bg-yellow-400 text-black hover:bg-yellow-500"
                onClick={() => {
                  if (searchQuery.trim()) {
                    setShowDropdown(false);
                    onSearch(searchQuery.trim());
                  }
                }}
              >
                <Search className="h-4 w-4" />
              </Button>

              {/* Suggestions Dropdown */}
              {showDropdown && suggestions.length > 0 && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-card border border-border rounded-xl shadow-xl z-50 max-h-80 overflow-y-auto">
                  <div className="p-2">
                    {suggestions.map((suggestion) => (
                      <button
                        key={`${suggestion.type}-${suggestion.id}`}
                        className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-muted/50 transition-colors text-left"
                        onClick={() => handleSelectSuggestion(suggestion)}
                      >
                        <div className="h-10 w-10 rounded-lg bg-yellow-400/10 flex items-center justify-center shrink-0">
                          {getTypeIcon(suggestion.type)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="font-medium truncate">{suggestion.name}</div>
                          <div className="text-sm text-muted-foreground flex items-center gap-2">
                            <Badge variant="outline" className="text-xs">
                              {getTypeLabel(suggestion.type)}
                            </Badge>
                            {suggestion.cantonName && (
                              <span className="truncate">{suggestion.cantonName}</span>
                            )}
                          </div>
                        </div>
                        {suggestion.distance !== undefined && (
                          <div className="text-sm text-yellow-400 font-medium shrink-0">
                            {suggestion.distance.toFixed(1)} km
                          </div>
                        )}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
            
            {userLocation && (
              <p className="text-xs text-muted-foreground mt-2 flex items-center justify-center gap-1">
                <Navigation className="h-3 w-3" />
                Mostrando distancias desde tu ubicación
              </p>
            )}
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-6 mt-12 max-w-2xl mx-auto">
            {[
              { value: "500+", label: "Conductores", icon: Users },
              { value: "24/7", label: "Disponibilidad", icon: Clock },
              { value: "100%", label: "Verificados", icon: Shield },
            ].map((stat) => (
              <div key={stat.label} className="text-center">
                <stat.icon className="h-6 w-6 mx-auto mb-2 text-yellow-400" />
                <div className="text-2xl md:text-3xl font-bold">{stat.value}</div>
                <div className="text-sm text-gray-500">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

// Taxi Card
function TaxiCard({ driver }: { driver: TaxiDriver }) {
  const handleCall = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    window.location.href = `tel:${driver.phone}`;
  };

  const handleWhatsApp = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const phone = driver.whatsapp || driver.phone;
    window.open(`https://wa.me/${phone.replace(/\D/g, "")}`, "_blank");
  };

  const vehicleInfo = vehicleTypeConfig[driver.vehicleType] || vehicleTypeConfig.taxi;
  const profileUrl = `/${driver.canton.slug}/${driver.city.slug}/${driver.slug}`;

  return (
    <Link href={profileUrl}>
      <Card className="group overflow-hidden border-border bg-card hover:border-yellow-400/50 transition-all duration-300 cursor-pointer h-full">
        <CardContent className="p-0">
          <div className="relative h-32 bg-gradient-to-br from-yellow-400/20 to-yellow-400/5 flex items-center justify-center overflow-hidden">
            {driver.imageUrl ? (
              <img
                src={driver.imageUrl}
                alt={driver.name}
                className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity"
              />
            ) : (
              <Car className="h-16 w-16 text-yellow-400/40" />
            )}
            
            <div className="absolute top-3 left-3 flex gap-2">
              {driver.isVerified && (
                <Badge className="bg-green-500/90 text-white border-0">
                  <CheckCircle className="mr-1 h-3 w-3" />
                  Verificado
                </Badge>
              )}
              {driver.isTopRated && (
                <Badge className="bg-yellow-400/90 text-black border-0">
                  <Award className="mr-1 h-3 w-3" />
                  Top
                </Badge>
              )}
            </div>

            <div className="absolute top-3 right-3 flex gap-2">
              {driver.isAvailable24h && (
                <Badge variant="secondary" className="bg-background/80 backdrop-blur-sm">
                  <Clock className="mr-1 h-3 w-3" />
                  24/7
                </Badge>
              )}
            </div>

            <div className="absolute bottom-3 left-3">
              <Badge variant="secondary" className="bg-background/80 backdrop-blur-sm text-sm">
                {vehicleInfo.icon} {vehicleInfo.label}
              </Badge>
            </div>
          </div>

          <div className="p-4">
            <div className="flex items-start justify-between mb-2">
              <div>
                <h3 className="font-semibold text-lg group-hover:text-yellow-400 transition-colors">
                  {driver.name}
                </h3>
                <p className="text-sm text-gray-500 flex items-center gap-1">
                  <MapPin className="h-3 w-3" />
                  {driver.city.name}, {driver.canton.name}
                </p>
              </div>
              <div className="text-right">
                <div className="flex items-center gap-1 text-sm">
                  <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  <span className="font-semibold">{driver.rating?.toFixed(1) || "5.0"}</span>
                </div>
                <p className="text-xs text-gray-500">{driver.experience} años</p>
              </div>
            </div>

            <div className="flex flex-wrap gap-1.5 mb-4">
              {driver.services.slice(0, 3).map((service) => {
                const config = serviceConfig[service];
                if (!config) return null;
                const Icon = config.icon;
                return (
                  <Badge key={service} variant="secondary" className="text-xs gap-1">
                    <Icon className="h-3 w-3" />
                    {config.label}
                  </Badge>
                );
              })}
            </div>

            <div className="flex gap-2">
              <Button
                size="sm"
                className="flex-1 bg-yellow-400 text-black hover:bg-yellow-500"
                onClick={handleCall}
              >
                <Phone className="mr-1.5 h-4 w-4" />
                Llamar
              </Button>
              <Button
                size="sm"
                variant="outline"
                className="flex-1 border-green-500 text-green-500 hover:bg-green-500 hover:text-white"
                onClick={handleWhatsApp}
              >
                <MessageCircle className="mr-1.5 h-4 w-4" />
                WhatsApp
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}

// Mobile Menu
function MobileMenu({
  open,
  onClose,
  cantons,
  onCantonSelect,
}: {
  open: boolean;
  onClose: () => void;
  cantons: Canton[];
  onCantonSelect: (canton: Canton) => void;
}) {
  return (
    <Sheet open={open} onOpenChange={(o) => !o && onClose()}>
      <SheetContent side="left" className="w-80 bg-card">
        <div className="py-6">
          <h3 className="font-semibold text-lg mb-4">Cantones</h3>
          <div className="space-y-2">
            {cantons.map((canton) => (
              <Button
                key={canton.id}
                variant="ghost"
                className="w-full justify-between"
                onClick={() => {
                  onCantonSelect(canton);
                  onClose();
                }}
              >
                {canton.name}
                <Badge variant="secondary">{canton._count?.drivers || 0}</Badge>
              </Button>
            ))}
          </div>
          
          <div className="mt-8 pt-6 border-t border-border">
            <Link href="/login" onClick={onClose}>
              <Button variant="outline" className="w-full mb-3">
                Acceder
              </Button>
            </Link>
            <Link href="/registrarse" onClick={onClose}>
              <Button className="w-full bg-yellow-400 text-black hover:bg-yellow-500">
                <Car className="mr-2 h-4 w-4" />
                Ser conductor
              </Button>
            </Link>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}

// Footer
function Footer() {
  return (
    <footer className="border-t border-border bg-card/50 mt-auto">
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4">
          <Link href="/" className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-yellow-400 to-yellow-500">
              <Car className="h-4 w-4 text-black" />
            </div>
            <span className="text-lg font-bold">
              <span className="text-yellow-400">Ei</span>
              <span className="text-white">Taxi</span>
            </span>
          </Link>
          <p className="text-sm text-gray-500">
            © 2026 EiTaxi. Todos los derechos reservados.
          </p>
        </div>
      </div>
    </footer>
  );
}

// Main Page
export default function EiTaxiPage() {
  const [drivers, setDrivers] = useState<TaxiDriver[]>([]);
  const [cantons, setCantons] = useState<Canton[]>([]);
  const [loading, setLoading] = useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Fetch initial data
  useEffect(() => {
    const fetchData = async () => {
      try {
        const [driversRes, cantonsRes] = await Promise.all([
          fetch("/api/taxis"),
          fetch("/api/cantons"),
        ]);

        const driversData = await driversRes.json();
        const cantonsData = await cantonsRes.json();

        if (driversData.success) {
          setDrivers(driversData.data);
        }
        if (cantonsData.success) {
          setCantons(cantonsData.data);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const handleCantonSelect = (canton: Canton) => {
    // Scroll to drivers section
    document.getElementById('drivers-section')?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSuggestionSelect = async (suggestion: LocationSuggestion) => {
    setLoading(true);
    try {
      // Fetch all drivers and filter based on suggestion
      const driversRes = await fetch("/api/taxis");
      const driversData = await driversRes.json();
      
      if (driversData.success) {
        let filtered = driversData.data;
        
        if (suggestion.type === 'city') {
          filtered = driversData.data.filter((d: TaxiDriver) => d.city.id === suggestion.id);
        } else if (suggestion.type === 'canton') {
          filtered = driversData.data.filter((d: TaxiDriver) => d.canton.id === suggestion.id);
        }
        
        setDrivers(filtered.length > 0 ? filtered : driversData.data);
      }
    } catch (error) {
      console.error("Error filtering drivers:", error);
    } finally {
      setLoading(false);
      // Scroll to drivers section
      document.getElementById('drivers-section')?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSearch = async (query: string) => {
    // Search for locations and filter drivers
    setLoading(true);
    try {
      const locationsRes = await fetch(`/api/locations?q=${encodeURIComponent(query)}`);
      const locationsData = await locationsRes.json();
      
      if (locationsData.success) {
        // Get all city IDs from the search results
        const cityIds = locationsData.data.suggestions
          .filter((s: LocationSuggestion) => s.type === 'city')
          .map((c: { id: string }) => c.id);
        const cantonIds = locationsData.data.suggestions
          .filter((s: LocationSuggestion) => s.type === 'canton')
          .map((c: { id: string }) => c.id);
        
        // Filter drivers based on location
        const driversRes = await fetch("/api/taxis");
        const driversData = await driversRes.json();
        
        if (driversData.success) {
          const filtered = driversData.data.filter((d: TaxiDriver) => 
            cityIds.includes(d.city.id) || cantonIds.includes(d.canton.id) ||
            d.city.name.toLowerCase().includes(query.toLowerCase()) ||
            d.canton.name.toLowerCase().includes(query.toLowerCase()) ||
            d.name.toLowerCase().includes(query.toLowerCase())
          );
          setDrivers(filtered.length > 0 ? filtered : driversData.data);
        }
      }
    } catch (error) {
      console.error("Error searching:", error);
    } finally {
      setLoading(false);
      // Scroll to drivers section
      document.getElementById('drivers-section')?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Header
        cantons={cantons}
        onCantonSelect={handleCantonSelect}
        onMobileMenuOpen={() => setMobileMenuOpen(true)}
      />

      <main className="flex-1">
        <HeroSection 
          onSearch={handleSearch}
          onSuggestionSelect={handleSuggestionSelect}
        />

        <section id="drivers-section" className="py-12 md:py-16">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
              <div>
                <h2 className="text-2xl md:text-3xl font-bold">Conductores disponibles</h2>
                <p className="text-gray-500">
                  {loading ? "Cargando..." : `${drivers.length} conductores encontrados`}
                </p>
              </div>
            </div>

            {loading ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {[...Array(8)].map((_, i) => (
                  <div
                    key={i}
                    className="h-80 rounded-xl bg-card animate-pulse border border-border"
                  />
                ))}
              </div>
            ) : drivers.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {drivers.map((driver) => (
                  <TaxiCard key={driver.id} driver={driver} />
                ))}
              </div>
            ) : (
              <div className="text-center py-16">
                <Car className="h-16 w-16 mx-auto text-gray-600 mb-4" />
                <h3 className="text-xl font-semibold mb-2">No se encontraron conductores</h3>
                <p className="text-gray-500">Prueba con otros filtros o busca en otra zona</p>
              </div>
            )}
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 bg-gradient-to-br from-yellow-400/10 via-transparent to-yellow-400/5">
          <div className="container mx-auto px-4 text-center">
            <div className="max-w-2xl mx-auto">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">¿Eres conductor en Suiza?</h2>
              <p className="text-lg text-gray-400 mb-8">
                Únete a nuestra plataforma y conecta con miles de pasajeros. Crea tu perfil profesional gratis.
              </p>
              <Link href="/registrarse">
                <Button size="lg" className="bg-yellow-400 text-black hover:bg-yellow-500">
                  <Zap className="mr-2 h-5 w-5" />
                  Crear mi perfil gratis
                </Button>
              </Link>
            </div>
          </div>
        </section>
      </main>

      <Footer />

      <MobileMenu
        open={mobileMenuOpen}
        onClose={() => setMobileMenuOpen(false)}
        cantons={cantons}
        onCantonSelect={handleCantonSelect}
      />
    </div>
  );
}
