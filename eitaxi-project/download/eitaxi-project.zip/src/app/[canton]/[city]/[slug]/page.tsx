"use client";

import { useState, useEffect } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import {
  Phone,
  MessageCircle,
  MapPin,
  Clock,
  Star,
  CheckCircle,
  Award,
  Car,
  Plane,
  Building2,
  Route,
  Shield,
  Globe,
  Users,
  Calendar,
  ArrowLeft,
  Share2,
  Navigation,
  Zap,
  Mail,
  ChevronRight,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

// Types
interface Driver {
  id: string;
  name: string;
  slug: string;
  phone: string;
  whatsapp: string | null;
  email: string | null;
  description: string | null;
  imageUrl: string | null;
  experience: number;
  vehicleType: string;
  vehicleBrand: string | null;
  vehicleModel: string | null;
  vehicleYear: number | null;
  vehicleColor: string | null;
  passengerCapacity: number | null;
  isAvailable24h: boolean;
  isVerified: boolean;
  isTopRated: boolean;
  rating: number;
  reviewCount: number;
  views: number;
  services: string[];
  languages: string[];
  serviceZones: string[];
  city: { name: string; slug: string };
  canton: { name: string; code: string; slug: string };
}

// Service config
const serviceConfig: Record<string, { icon: typeof Car; label: string; description: string }> = {
  airport: { icon: Plane, label: "Aeropuerto", description: "Traslados al aeropuerto" },
  city: { icon: Building2, label: "Ciudad", description: "Viajes urbanos" },
  long_distance: { icon: Route, label: "Larga distancia", description: "Viajes interurbanos" },
  limousine: { icon: Car, label: "Limusina", description: "Servicio de lujo" },
  corporate: { icon: Shield, label: "Corporativo", description: "Empresas y ejecutivos" },
  events: { icon: Calendar, label: "Eventos", description: "Bodas y celebraciones" },
  delivery: { icon: Route, label: "Entregas", description: "Mensajería y paquetería" },
  night: { icon: Clock, label: "Nocturno", description: "Servicio de noche" },
};

// Language config
const languageConfig: Record<string, { flag: string; name: string }> = {
  de: { flag: "🇩🇪", name: "Alemán" },
  en: { flag: "🇬🇧", name: "Inglés" },
  fr: { flag: "🇫🇷", name: "Francés" },
  it: { flag: "🇮🇹", name: "Italiano" },
  es: { flag: "🇪🇸", name: "Español" },
  pt: { flag: "🇵🇹", name: "Portugués" },
  ru: { flag: "🇷🇺", name: "Ruso" },
  zh: { flag: "🇨🇳", name: "Chino" },
};

// Vehicle type config
const vehicleTypeConfig: Record<string, { label: string; icon: string }> = {
  taxi: { label: "Taxi", icon: "🚕" },
  limousine: { label: "Limusina", icon: "🚗" },
  van: { label: "Van", icon: "🚐" },
  premium: { label: "Premium", icon: "✨" },
};

// Mock reviews
const mockReviews = [
  {
    id: "1",
    author: "María G.",
    rating: 5,
    date: "Hace 2 semanas",
    comment: "Excelente servicio, muy puntual y profesional. El vehículo impecable.",
  },
  {
    id: "2",
    author: "Thomas M.",
    rating: 5,
    date: "Hace 1 mes",
    comment: "Muy buen conductor, me ayudó con las maletas. Recomendado.",
  },
  {
    id: "3",
    author: "Sofia L.",
    rating: 5,
    date: "Hace 1 mes",
    comment: "Traslado perfecto al aeropuerto. Conducía con mucho cuidado.",
  },
];

export default function DriverProfilePage() {
  const params = useParams();
  const [driver, setDriver] = useState<Driver | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchDriver = async () => {
      try {
        const res = await fetch(
          `/api/drivers?slug=${params.slug}&canton=${params.canton}&city=${params.city}`
        );
        const data = await res.json();

        if (data.success) {
          setDriver(data.data);
        } else {
          setError(data.error || "Conductor no encontrado");
        }
      } catch (err) {
        setError("Error al cargar el perfil");
      } finally {
        setLoading(false);
      }
    };

    if (params.slug) {
      fetchDriver();
    }
  }, [params.slug, params.canton, params.city]);

  const handleCall = () => {
    if (driver) {
      window.location.href = `tel:${driver.phone}`;
    }
  };

  const handleWhatsApp = () => {
    if (driver) {
      const phone = driver.whatsapp || driver.phone;
      window.open(`https://wa.me/${phone.replace(/\D/g, "")}`, "_blank");
    }
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `${driver?.name} - EiTaxi`,
          url: window.location.href,
        });
      } catch (err) {
        // User cancelled or error
      }
    } else {
      // Fallback: copy to clipboard
      navigator.clipboard.writeText(window.location.href);
    }
  };

  // Loading state
  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0a0a]">
        {/* Header skeleton */}
        <div className="h-16 border-b border-white/5 animate-pulse bg-white/5" />
        
        {/* Hero skeleton */}
        <div className="relative h-[60vh] bg-white/5 animate-pulse" />
        
        {/* Content skeleton */}
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-4xl mx-auto space-y-6">
            <div className="h-12 bg-white/5 rounded animate-pulse w-1/2" />
            <div className="h-6 bg-white/5 rounded animate-pulse w-1/3" />
            <div className="h-32 bg-white/5 rounded animate-pulse" />
          </div>
        </div>
      </div>
    );
  }

  // Error state
  if (error || !driver) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center p-4">
        <Card className="max-w-md w-full p-8 text-center border-white/10 bg-[#111]">
          <Car className="h-16 w-16 mx-auto text-amber-500/50 mb-4" />
          <h1 className="text-2xl font-bold mb-2 text-white">Conductor no encontrado</h1>
          <p className="text-zinc-400 mb-6">
            {error || "El perfil que buscas no existe o ha sido eliminado."}
          </p>
          <Link href="/">
            <Button className="bg-amber-500 text-black hover:bg-amber-400">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Volver al inicio
            </Button>
          </Link>
        </Card>
      </div>
    );
  }

  const vehicleInfo = vehicleTypeConfig[driver.vehicleType] || vehicleTypeConfig.taxi;

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b border-white/5 bg-[#0a0a0a]/95 backdrop-blur-xl">
        <div className="container mx-auto px-4">
          <div className="flex h-16 items-center justify-between">
            {/* Logo */}
            <Link href="/" className="flex items-center gap-2">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-amber-400 to-amber-500">
                <Car className="h-6 w-6 text-black" />
              </div>
              <span className="text-xl font-bold">
                <span className="text-amber-400">Ei</span>
                <span className="text-white">Taxi</span>
              </span>
            </Link>

            {/* Actions */}
            <div className="flex items-center gap-2">
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={handleShare}
                className="text-zinc-400 hover:text-white hover:bg-white/5"
              >
                <Share2 className="h-5 w-5" />
              </Button>
              <Button
                className="bg-amber-500 text-black hover:bg-amber-400 font-medium"
                onClick={handleCall}
              >
                <Phone className="mr-2 h-4 w-4" />
                Llamar
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section with Cover */}
      <section className="relative h-[50vh] md:h-[60vh] overflow-hidden">
        {/* Background gradient */}
        <div className="absolute inset-0 bg-gradient-to-b from-amber-900/20 via-[#0a0a0a] to-[#0a0a0a]" />
        
        {/* Cover pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0" style={{
            backgroundImage: `radial-gradient(circle at 25% 25%, rgba(245, 158, 11, 0.3) 0%, transparent 50%), 
                              radial-gradient(circle at 75% 75%, rgba(245, 158, 11, 0.2) 0%, transparent 50%)`
          }} />
        </div>
        
        {/* Image or placeholder */}
        {driver.imageUrl ? (
          <img
            src={driver.imageUrl}
            alt={driver.name}
            className="absolute inset-0 w-full h-full object-cover opacity-20"
          />
        ) : null}
        
        {/* Overlay gradient */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0a] via-[#0a0a0a]/80 to-transparent" />

        {/* Content */}
        <div className="absolute bottom-0 left-0 right-0 p-6 md:p-12">
          <div className="container mx-auto">
            <div className="max-w-4xl">
              {/* Driver Photo and Info */}
              <div className="flex flex-col md:flex-row items-start gap-6">
                {/* Driver Photo */}
                <div className="relative">
                  <div className="w-28 h-28 md:w-36 md:h-36 rounded-2xl overflow-hidden border-4 border-[#0a0a0a] shadow-2xl bg-[#1a1a1a]">
                    {driver.imageUrl ? (
                      <img
                        src={driver.imageUrl}
                        alt={driver.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <Car className="h-12 w-12 text-amber-500/50" />
                      </div>
                    )}
                  </div>
                  {/* Online indicator */}
                  {driver.isAvailable24h && (
                    <div className="absolute -bottom-2 -right-2 w-8 h-8 rounded-full bg-green-500 flex items-center justify-center border-4 border-[#0a0a0a]">
                      <div className="w-3 h-3 rounded-full bg-white animate-pulse" />
                    </div>
                  )}
                </div>

                {/* Driver Info */}
                <div className="flex-1">
                  {/* Badges */}
                  <div className="flex flex-wrap gap-2 mb-3">
                    {driver.isVerified && (
                      <Badge className="bg-green-500/20 text-green-400 border-0 text-xs font-medium">
                        <CheckCircle className="mr-1 h-3 w-3" />
                        Verificado
                      </Badge>
                    )}
                    {driver.isTopRated && (
                      <Badge className="bg-amber-500/20 text-amber-400 border-0 text-xs font-medium">
                        <Award className="mr-1 h-3 w-3" />
                        Top Rated
                      </Badge>
                    )}
                    <Badge className="bg-white/10 text-zinc-300 border-0 text-xs font-medium">
                      <span className="mr-1">{vehicleInfo.icon}</span>
                      {vehicleInfo.label}
                    </Badge>
                    {driver.isAvailable24h && (
                      <Badge className="bg-green-500/20 text-green-400 border-0 text-xs font-medium">
                        <Clock className="mr-1 h-3 w-3" />
                        24/7
                      </Badge>
                    )}
                  </div>

                  {/* Name */}
                  <h1 className="text-3xl md:text-5xl font-bold mb-2 text-white">
                    {driver.name}
                  </h1>

                  {/* Location */}
                  <p className="text-lg text-zinc-400 flex items-center gap-2 mb-4">
                    <MapPin className="h-5 w-5 text-amber-500" />
                    {driver.city.name}, {driver.canton.name}
                  </p>

                  {/* Rating */}
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-1.5">
                      <div className="flex">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <Star
                            key={star}
                            className={`h-5 w-5 ${
                              star <= Math.round(driver.rating)
                                ? "fill-amber-400 text-amber-400"
                                : "fill-zinc-700 text-zinc-700"
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-lg font-bold text-white ml-2">{driver.rating.toFixed(1)}</span>
                    </div>
                    <span className="text-zinc-500">|</span>
                    <span className="text-zinc-400">{driver.experience}+ años de experiencia</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="border-b border-white/5 bg-[#0f0f0f]">
        <div className="container mx-auto px-4 py-6">
          <div className="max-w-4xl mx-auto grid grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-2xl md:text-3xl font-bold text-amber-400">
                {driver.experience}+
              </div>
              <div className="text-xs md:text-sm text-zinc-500">Años exp.</div>
            </div>
            <div className="text-center">
              <div className="text-2xl md:text-3xl font-bold text-amber-400">
                {driver.views}+
              </div>
              <div className="text-xs md:text-sm text-zinc-500">Clientes</div>
            </div>
            <div className="text-center">
              <div className="text-2xl md:text-3xl font-bold text-amber-400">
                {driver.rating.toFixed(1)}
              </div>
              <div className="text-xs md:text-sm text-zinc-500">Rating</div>
            </div>
            <div className="text-center">
              <div className="text-2xl md:text-3xl font-bold text-amber-400">
                100%
              </div>
              <div className="text-xs md:text-sm text-zinc-500">Puntual</div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8 md:py-12 pb-28 md:pb-12">
        <div className="max-w-4xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Left Column - Main Info */}
            <div className="lg:col-span-2 space-y-6">
              {/* Contact Card - Mobile */}
              <Card className="border-amber-500/20 bg-gradient-to-br from-amber-500/10 to-transparent lg:hidden">
                <CardContent className="p-4">
                  <div className="flex gap-3">
                    <Button
                      className="flex-1 bg-amber-500 text-black hover:bg-amber-400 h-12 font-medium"
                      onClick={handleCall}
                    >
                      <Phone className="mr-2 h-5 w-5" />
                      Llamar
                    </Button>
                    <Button
                      variant="outline"
                      className="flex-1 border-green-500 text-green-500 hover:bg-green-500 hover:text-white h-12 font-medium"
                      onClick={handleWhatsApp}
                    >
                      <MessageCircle className="mr-2 h-5 w-5" />
                      WhatsApp
                    </Button>
                  </div>
                  <div className="mt-3 text-center">
                    <a
                      href={`tel:${driver.phone}`}
                      className="text-lg font-medium text-amber-400 hover:underline"
                    >
                      {driver.phone}
                    </a>
                  </div>
                </CardContent>
              </Card>

              {/* Services Section */}
              <Card className="border-white/5 bg-[#111]">
                <CardContent className="p-6">
                  <h2 className="text-lg font-semibold mb-4 flex items-center gap-2 text-white">
                    <Zap className="h-5 w-5 text-amber-400" />
                    Servicios
                  </h2>
                  <div className="flex flex-wrap gap-2">
                    {driver.services.map((serviceId) => {
                      const service = serviceConfig[serviceId];
                      if (!service) return null;
                      const Icon = service.icon;
                      return (
                        <Badge
                          key={serviceId}
                          className="bg-white/5 text-zinc-300 border border-white/10 py-2 px-3 gap-2 hover:bg-amber-500/10 hover:text-amber-400 hover:border-amber-500/30 transition-colors"
                        >
                          <Icon className="h-4 w-4" />
                          {service.label}
                        </Badge>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>

              {/* About Section */}
              {driver.description && (
                <Card className="border-white/5 bg-[#111]">
                  <CardContent className="p-6">
                    <h2 className="text-lg font-semibold mb-4 text-white">Sobre mí</h2>
                    <p className="text-zinc-400 leading-relaxed">
                      {driver.description}
                    </p>
                  </CardContent>
                </Card>
              )}

              {/* Vehicle Section */}
              <Card className="border-white/5 bg-[#111]">
                <CardContent className="p-6">
                  <h2 className="text-lg font-semibold mb-4 flex items-center gap-2 text-white">
                    <Car className="h-5 w-5 text-amber-400" />
                    Vehículo
                  </h2>
                  <div className="flex items-center gap-4 p-4 rounded-xl bg-white/5 border border-white/5">
                    <div className="text-4xl">{vehicleInfo.icon}</div>
                    <div className="flex-1">
                      <div className="font-semibold text-lg text-white">
                        {driver.vehicleBrand || 'Vehículo'} {driver.vehicleModel || 'Profesional'}
                      </div>
                      <div className="text-zinc-500 flex flex-wrap gap-x-4 gap-y-1 mt-1 text-sm">
                        {driver.vehicleYear && <span>Año: {driver.vehicleYear}</span>}
                        {driver.vehicleColor && <span>Color: {driver.vehicleColor}</span>}
                        {driver.passengerCapacity && (
                          <span className="flex items-center gap-1">
                            <Users className="h-3 w-3" />
                            {driver.passengerCapacity} pasajeros
                          </span>
                        )}
                      </div>
                    </div>
                    <ChevronRight className="h-5 w-5 text-zinc-600" />
                  </div>
                </CardContent>
              </Card>

              {/* Service Zones */}
              {driver.serviceZones && driver.serviceZones.length > 0 && (
                <Card className="border-white/5 bg-[#111]">
                  <CardContent className="p-6">
                    <h2 className="text-lg font-semibold mb-4 flex items-center gap-2 text-white">
                      <Navigation className="h-5 w-5 text-amber-400" />
                      Zonas de servicio
                    </h2>
                    <div className="flex flex-wrap gap-2">
                      {driver.serviceZones.map((zone, index) => (
                        <Badge
                          key={index}
                          className="bg-white/5 text-zinc-400 border border-white/10 py-1.5 px-3"
                        >
                          <MapPin className="mr-1.5 h-3 w-3" />
                          {zone}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Reviews Section */}
              <Card className="border-white/5 bg-[#111]">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-lg font-semibold text-white">Reseñas</h2>
                    <Badge className="bg-amber-500/20 text-amber-400 border-0">
                      {mockReviews.length} reseñas
                    </Badge>
                  </div>
                  
                  <div className="space-y-4">
                    {mockReviews.map((review) => (
                      <div key={review.id} className="p-4 rounded-xl bg-white/5 border border-white/5">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-3">
                            <Avatar className="h-10 w-10 bg-amber-500/20">
                              <AvatarFallback className="text-amber-400 font-medium">
                                {review.author.split(' ').map(n => n[0]).join('')}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <div className="font-medium text-white">{review.author}</div>
                              <div className="text-xs text-zinc-500">{review.date}</div>
                            </div>
                          </div>
                          <div className="flex">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <Star
                                key={star}
                                className={`h-4 w-4 ${
                                  star <= review.rating
                                    ? "fill-amber-400 text-amber-400"
                                    : "fill-zinc-700 text-zinc-700"
                                }`}
                              />
                            ))}
                          </div>
                        </div>
                        <p className="text-zinc-400 text-sm">{review.comment}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Right Column - Sidebar (Desktop) */}
            <div className="hidden lg:block space-y-6">
              {/* Contact Card */}
              <Card className="border-amber-500/20 bg-gradient-to-br from-amber-500/10 to-transparent sticky top-24">
                <CardContent className="p-6">
                  <h3 className="font-semibold mb-4 text-white">Contactar</h3>
                  
                  {/* CTA Buttons */}
                  <div className="space-y-3">
                    <Button
                      className="w-full bg-amber-500 text-black hover:bg-amber-400 h-12 font-medium"
                      onClick={handleCall}
                    >
                      <Phone className="mr-2 h-5 w-5" />
                      Llamar ahora
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full border-green-500 text-green-500 hover:bg-green-500 hover:text-white h-12 font-medium"
                      onClick={handleWhatsApp}
                    >
                      <MessageCircle className="mr-2 h-5 w-5" />
                      WhatsApp
                    </Button>
                  </div>

                  {/* Phone number */}
                  <div className="mt-4 pt-4 border-t border-white/10">
                    <div className="text-sm text-zinc-500">Teléfono</div>
                    <a
                      href={`tel:${driver.phone}`}
                      className="text-lg font-medium text-amber-400 hover:underline"
                    >
                      {driver.phone}
                    </a>
                  </div>

                  {/* Availability */}
                  {driver.isAvailable24h && (
                    <div className="mt-4 p-3 rounded-lg bg-green-500/10 border border-green-500/20">
                      <div className="flex items-center gap-2 text-green-400">
                        <Clock className="h-4 w-4" />
                        <span className="font-medium">Disponible ahora</span>
                      </div>
                      <p className="text-sm text-zinc-500 mt-1">
                        Servicio 24 horas, 7 días
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Languages Card */}
              {driver.languages && driver.languages.length > 0 && (
                <Card className="border-white/5 bg-[#111]">
                  <CardContent className="p-6">
                    <h3 className="font-semibold mb-4 flex items-center gap-2 text-white">
                      <Globe className="h-5 w-5 text-amber-400" />
                      Idiomas
                    </h3>
                    <div className="flex flex-wrap gap-2">
                      {driver.languages.map((langId) => {
                        const lang = languageConfig[langId];
                        if (!lang) return null;
                        return (
                          <Badge
                            key={langId}
                            className="bg-white/5 text-zinc-300 border border-white/10 py-1.5"
                          >
                            <span className="mr-1.5">{lang.flag}</span>
                            {lang.name}
                          </Badge>
                        );
                      })}
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Location Card */}
              <Card className="border-white/5 bg-[#111]">
                <CardContent className="p-6">
                  <h3 className="font-semibold mb-4 flex items-center gap-2 text-white">
                    <MapPin className="h-5 w-5 text-amber-400" />
                    Ubicación
                  </h3>
                  <div className="space-y-2">
                    <div className="font-medium text-white">{driver.city.name}</div>
                    <div className="text-zinc-500">
                      {driver.canton.name}, Suiza
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>

      {/* Bottom CTA - Mobile */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-[#0a0a0a]/95 backdrop-blur-xl border-t border-white/5 lg:hidden z-50">
        <div className="flex gap-3">
          <Button
            className="flex-1 bg-amber-500 text-black hover:bg-amber-400 h-14 font-medium"
            onClick={handleCall}
          >
            <Phone className="mr-2 h-5 w-5" />
            Llamar
          </Button>
          <Button
            variant="outline"
            className="flex-1 border-green-500 text-green-500 hover:bg-green-500 hover:text-white h-14 font-medium"
            onClick={handleWhatsApp}
          >
            <MessageCircle className="mr-2 h-5 w-5" />
            WhatsApp
          </Button>
        </div>
      </div>

      {/* Footer */}
      <footer className="border-t border-white/5 bg-[#0a0a0a] mt-12 pb-24 lg:pb-0">
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-4xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4">
            <Link href="/" className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-amber-400 to-amber-500">
                <Car className="h-4 w-4 text-black" />
              </div>
              <span className="text-lg font-bold">
                <span className="text-amber-400">Ei</span>
                <span className="text-white">Taxi</span>
              </span>
            </Link>
            <p className="text-sm text-zinc-600">
              © 2026 EiTaxi. Todos los derechos reservados.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
