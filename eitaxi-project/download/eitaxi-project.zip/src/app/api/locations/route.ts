import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getDistance } from 'geolib'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const query = searchParams.get('q')?.toLowerCase() || ''
    const type = searchParams.get('type') || 'all'
    const lat = searchParams.get('lat')
    const lng = searchParams.get('lng')
    
    if (!query || query.length < 1) {
      return NextResponse.json({
        success: true,
        data: { suggestions: [] }
      })
    }

    const suggestions: Array<{
      id: string;
      name: string;
      type: 'city' | 'canton' | 'place';
      cantonName?: string;
      distance?: number;
      latitude: number;
      longitude: number;
    }> = []

    // Buscar ciudades
    if (type === 'all' || type === 'cities') {
      const cities = await db.city.findMany({
        where: {
          OR: [
            { name: { contains: query } },
            { postalCode: { contains: query } }
          ]
        },
        include: { canton: true },
        take: 15
      })
      
      for (const city of cities) {
        let distance: number | undefined
        if (lat && lng) {
          distance = getDistance(
            { latitude: parseFloat(lat), longitude: parseFloat(lng) },
            { latitude: city.latitude, longitude: city.longitude }
          ) / 1000 // Convertir a km
        }
        
        suggestions.push({
          id: city.id,
          name: city.name,
          type: 'city',
          cantonName: city.canton.name,
          distance,
          latitude: city.latitude,
          longitude: city.longitude,
        })
      }
    }

    // Buscar cantones
    if (type === 'all' || type === 'cantons') {
      const cantons = await db.canton.findMany({
        where: {
          OR: [
            { name: { contains: query } },
            { code: { contains: query.toUpperCase() } }
          ]
        },
        take: 5
      })
      
      for (const canton of cantons) {
        let distance: number | undefined
        if (lat && lng) {
          distance = getDistance(
            { latitude: parseFloat(lat), longitude: parseFloat(lng) },
            { latitude: canton.latitude, longitude: canton.longitude }
          ) / 1000
        }
        
        suggestions.push({
          id: canton.id,
          name: canton.name,
          type: 'canton',
          distance,
          latitude: canton.latitude,
          longitude: canton.longitude,
        })
      }
    }

    // Buscar lugares de interés
    if (type === 'all' || type === 'places') {
      const places = await db.place.findMany({
        where: {
          OR: [
            { name: { contains: query } },
            { type: { contains: query } }
          ]
        },
        take: 10
      })
      
      for (const place of places) {
        let distance: number | undefined
        if (lat && lng) {
          distance = getDistance(
            { latitude: parseFloat(lat), longitude: parseFloat(lng) },
            { latitude: place.latitude, longitude: place.longitude }
          ) / 1000
        }
        
        suggestions.push({
          id: place.id,
          name: place.name,
          type: 'place',
          distance,
          latitude: place.latitude,
          longitude: place.longitude,
        })
      }
    }

    // Ordenar por relevancia (priorizar coincidencias exactas al inicio)
    suggestions.sort((a, b) => {
      // Si hay distancia, ordenar por cercanía
      if (a.distance !== undefined && b.distance !== undefined) {
        return a.distance - b.distance
      }
      // Ordenar por nombre
      const aStartsWithQuery = a.name.toLowerCase().startsWith(query)
      const bStartsWithQuery = b.name.toLowerCase().startsWith(query)
      if (aStartsWithQuery && !bStartsWithQuery) return -1
      if (!aStartsWithQuery && bStartsWithQuery) return 1
      return a.name.localeCompare(b.name)
    })

    return NextResponse.json({
      success: true,
      data: {
        suggestions: suggestions.slice(0, 20)
      }
    })
  } catch (error) {
    console.error('Error searching locations:', error)
    return NextResponse.json(
      { success: false, error: 'Error al buscar ubicaciones' },
      { status: 500 }
    )
  }
}

// Endpoint para calcular distancia entre dos puntos
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { origin, destination } = body

    if (!origin || !destination) {
      return NextResponse.json(
        { success: false, error: 'Origen y destino son requeridos' },
        { status: 400 }
      )
    }

    // Calcular distancia
    const distance = getDistance(
      { latitude: origin.lat, longitude: origin.lng },
      { latitude: destination.lat, longitude: destination.lng }
    ) / 1000 // Convertir a km

    // Estimar precio (promedio CHF 3-4 por km + base)
    const basePrice = 6.00
    const pricePerKm = 3.50
    const estimatedPrice = basePrice + (distance * pricePerKm)

    return NextResponse.json({
      success: true,
      data: {
        distance: Math.round(distance * 10) / 10, // Redondear a 1 decimal
        estimatedPrice: Math.round(estimatedPrice * 100) / 100,
        estimatedDuration: Math.round(distance * 1.5), // Minutos aproximados
      }
    })
  } catch (error) {
    console.error('Error calculating distance:', error)
    return NextResponse.json(
      { success: false, error: 'Error al calcular distancia' },
      { status: 500 }
    )
  }
}
