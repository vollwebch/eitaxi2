import { NextRequest, NextResponse } from "next/server";
import ZAI from "z-ai-web-dev-sdk";

// Fallback function to generate description without AI
function generateFallbackDescription(
  name: string,
  services: string[],
  experience: number,
  vehicleDesc: string,
  city: string,
  canton: string,
  languageList: string
): string {
  const serviceDescriptions: Record<string, string> = {
    airport: "traslados al aeropuerto",
    city: "viajes dentro de la ciudad",
    long_distance: "recorridos de larga distancia",
    limousine: "servicio de limusina de lujo",
    corporate: "transporte corporativo para empresas",
    events: "servicio para eventos y celebraciones",
    delivery: "entregas y mensajería",
    night: "servicio nocturno seguro",
  };

  const mainServices = services.slice(0, 3).map(s => serviceDescriptions[s] || s);
  const location = city && canton ? `en ${city}, ${canton}` : city ? `en ${city}` : canton ? `en el cantón de ${canton}` : "en Suiza";
  
  const descriptions = [
    `Conductor profesional con más de ${experience} años de experiencia ${location}. Especializado en ${mainServices.join(", ")}. Ofrezco un servicio seguro, puntual y confortable para todos mis pasajeros. Disponible para viajes locales y de larga distancia.`,
    
    `Servicio de transporte profesional ${location} con ${experience} años de experiencia. Mi ${vehicleDesc} está equipado para brindarte la mejor experiencia en ${mainServices.join(", ")}. Hablo ${languageList}. Servicio disponible 24/7.`,
    
    `Profesional del transporte con ${experience}+ años de experiencia ${location}. Me especializo en ${mainServices.join(", ")} y ofrezco un servicio personalizado y de alta calidad. Vehículo confortable y bien mantenido. ¡Contáctame para tu próximo viaje!`,
  ];
  
  return descriptions[Math.floor(Math.random() * descriptions.length)];
}

export async function POST(request: NextRequest) {
  let body;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json(
      { success: false, error: "Error al procesar la solicitud" },
      { status: 400 }
    );
  }

  const { 
    name, 
    services, 
    experience, 
    vehicleType, 
    vehicleTypes, 
    city, 
    canton, 
    languages,
    userDescription, // Descripción que el usuario ya escribió
    mode = 'improve' // 'improve' para mejorar, 'generate' para generar desde cero
  } = body;

  // Validate required fields
  if (!name) {
    return NextResponse.json(
      { success: false, error: "El nombre es requerido" },
      { status: 400 }
    );
  }

  // Create service descriptions
  const serviceDescriptions: Record<string, string> = {
    airport: "traslados al aeropuerto",
    city: "viajes dentro de la ciudad",
    long_distance: "recorridos de larga distancia",
    limousine: "servicio de limusina de lujo",
    corporate: "transporte corporativo para empresas",
    events: "servicio para eventos y celebraciones",
    delivery: "entregas y mensajería",
    night: "servicio nocturno seguro",
  };

  const serviceList = services && services.length > 0
    ? services.map((s: string) => serviceDescriptions[s] || s).join(", ")
    : "servicios de taxi";

  // Get vehicle type (support both single and multiple)
  const primaryVehicleType = vehicleTypes?.[0] || vehicleType || "taxi";
  const vehicleDescriptions: Record<string, string> = {
    taxi: "taxi estándar",
    limousine: "limusina de lujo",
    van: "van amplia para grupos",
    premium: "vehículo premium ejecutivo",
  };

  const vehicleDesc = vehicleDescriptions[primaryVehicleType] || "vehículo";

  // Language names
  const languageNames: Record<string, string> = {
    de: "alemán",
    en: "inglés",
    fr: "francés",
    it: "italiano",
    es: "español",
    pt: "portugués",
    ru: "ruso",
    zh: "chino",
  };

  const languageList = languages && languages.length > 0
    ? languages.map((l: string) => languageNames[l] || l).join(", ")
    : "varios idiomas";

  // Prepare fallback description
  const fallbackDesc = generateFallbackDescription(
    name, services || [], experience || 1, vehicleDesc, city || "", canton || "", languageList
  );

  // Si el usuario ya escribió algo y el modo es 'improve', mejorar su texto
  const promptMode = userDescription && userDescription.trim().length > 0
    ? `MEJORAR DESCRIPCIÓN EXISTENTE:
El taxista ha escrito esta descripción:
"${userDescription}"

INSTRUCCIONES ESPECÍFICAS:
1. Mejora y enriquece el texto que el taxista ya escribió
2. Mantén el tono y estilo personal del texto original
3. Añade detalles profesionales relevantes
4. Corrige errores gramaticales si los hay
5. Haz el texto más atractivo para clientes potenciales
6. NO cambies completamente el texto, solo mejóralo
7. Mantén la longitud similar o ligeramente mayor (máximo 350 caracteres)`
    : `GENERAR DESCRIPCIÓN NUEVA:
El taxista no ha escrito una descripción aún.

INSTRUCCIONES:
1. Crea una descripción profesional y atractiva desde cero
2. Máximo 300 caracteres
3. Incluye los servicios principales de forma natural`;

  try {
    const prompt = `Eres un experto en marketing para servicios de transporte de taxi en Suiza. Tu trabajo es ayudar a taxistas a tener descripciones profesionales y atractivas.

DATOS DEL CONDUCTOR:
- Nombre: ${name}
- Experiencia: ${experience || 1} años
- Tipo de vehículo: ${vehicleDesc}
- Ciudad: ${city || "Suiza"}
- Cantón: ${canton || ""}
- Servicios: ${serviceList}
- Idiomas: ${languageList}

${promptMode}

REGLAS GENERALES:
- Escribe en español profesional pero cercano
- NO uses comillas ni caracteres especiales extraños
- NO incluyas el nombre del conductor al inicio
- NO uses punto final si la descripción ya es corta
- El texto debe sonar natural, como si lo escribiera el mismo conductor

Genera SOLO el texto mejorado o creado, sin explicaciones adicionales.`;

    const zai = await ZAI.create();

    const completion = await Promise.race([
      zai.chat.completions.create({
        messages: [
          {
            role: "system",
            content: "Eres un asistente experto en redacción publicitaria para servicios de taxi en Suiza. Ayudas a mejorar los textos de los conductores manteniendo su voz personal."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        temperature: 0.7,
        max_tokens: 500,
      }),
      new Promise<null>((_, reject) => 
        setTimeout(() => reject(new Error("AI request timeout")), 15000)
      )
    ]);

    const description = completion && typeof completion === 'object' && 'choices' in completion
      ? completion.choices[0]?.message?.content?.trim() 
      : "";

    if (description) {
      return NextResponse.json({
        success: true,
        description,
        generatedBy: "ai",
        mode: userDescription ? "improved" : "generated"
      });
    }

    return NextResponse.json({
      success: true,
      description: fallbackDesc,
      generatedBy: "fallback"
    });

  } catch (error) {
    console.error("Error generating description with AI, using fallback:", error);
    
    return NextResponse.json({
      success: true,
      description: fallbackDesc,
      generatedBy: "fallback"
    });
  }
}
