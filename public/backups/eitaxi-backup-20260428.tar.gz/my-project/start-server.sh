#!/bin/bash
while true; do
  cd /home/z/my-project/.next/standalone
  DATABASE_URL=file:/home/z/my-project/db/custom.db node server.js 2>&1
  echo "$(date): Server exited, restarting in 2s..."
  sleep 2
done
