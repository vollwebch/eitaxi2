import { NextRequest, NextResponse } from 'next/server'
import bcrypt from 'bcryptjs'
import { db } from '@/lib/db'
import { requireAuth } from '@/lib/auth'

export async function POST(request: NextRequest) {
  try {
    let session
    try {
      session = await requireAuth(request)
    } catch {
      return NextResponse.json(
        { success: false, error: 'No autenticado' },
        { status: 401 }
      )
    }

    const body = await request.json()
    const { currentPassword, newEmail, newPassword } = body

    // Force ownership: always use session.driverId, ignore body.driverId
    const driverId = session.driverId

    // 🔒 No se registran datos de seguridad en producción
    // Solo se loguea en desarrollo para debugging
    if (process.env.NODE_ENV === 'development') {
      console.log('🔐 Security change request for driver:', driverId);
    }

    // Validation
    if (!driverId) {
      return NextResponse.json(
        { success: false, error: 'ID de conductor requerido' },
        { status: 400 }
      )
    }

    if (!currentPassword) {
      return NextResponse.json(
        { success: false, error: 'La contraseña actual es obligatoria' },
        { status: 400 }
      )
    }

    if (!newEmail && !newPassword) {
      return NextResponse.json(
        { success: false, error: 'No hay cambios que realizar' },
        { status: 400 }
      )
    }

    // Find driver
    const driver = await db.taxiDriver.findUnique({
      where: { id: driverId }
    })

    if (!driver) {
      return NextResponse.json(
        { success: false, error: 'Conductor no encontrado' },
        { status: 404 }
      )
    }

    // Verify current password
    const isValidPassword = await bcrypt.compare(currentPassword, driver.password)
    if (!isValidPassword) {
      return NextResponse.json(
        { success: false, error: 'La contraseña actual es incorrecta' },
        { status: 401 }
      )
    }

    // Prepare update data
    const updateData: Record<string, unknown> = {}

    // Handle email change
    if (newEmail && newEmail.toLowerCase() !== driver.email?.toLowerCase()) {
      // Check if email is already in use
      const existingDriver = await db.taxiDriver.findFirst({
        where: {
          email: newEmail.toLowerCase(),
          NOT: { id: driverId }
        }
      })

      if (existingDriver) {
        return NextResponse.json(
          { success: false, error: 'Este email ya está en uso por otro conductor' },
          { status: 400 }
        )
      }

      updateData.email = newEmail.toLowerCase().trim()
      // Email actualizado (no se registra el valor por privacidad)
    }

    // Handle password change
    if (newPassword) {
      if (newPassword.length < 8) {
        return NextResponse.json(
          { success: false, error: 'La nueva contraseña debe tener al menos 8 caracteres' },
          { status: 400 }
        )
      }
      // Validar complejidad: al menos una letra y un número
      if (!/[a-zA-Z]/.test(newPassword) || !/[0-9]/.test(newPassword)) {
        return NextResponse.json(
          { success: false, error: 'La contraseña debe contener al menos una letra y un número' },
          { status: 400 }
        )
      }
      updateData.password = await bcrypt.hash(newPassword, 10)
      // Contraseña actualizada (no se registra por seguridad)
    }

    // If no actual changes to make
    if (Object.keys(updateData).length === 0) {
      return NextResponse.json(
        { success: false, error: 'No hay cambios que realizar' },
        { status: 400 }
      )
    }

    // Update driver
    const updatedDriver = await db.taxiDriver.update({
      where: { id: driverId },
      data: updateData
    })

    console.log('✅ Security changes saved for driver:', driverId);
    const changes: string[] = []
    if (updateData.email) changes.push('email')
    if (updateData.password) changes.push('contraseña')

    return NextResponse.json({
      success: true,
      message: `Cambios guardados: ${changes.join(' y ')} actualizado${changes.length > 1 ? 's' : ''}`,
      newEmail: updateData.email || null,
    })

  } catch (error: any) {
    console.error('❌ Error in security change:', error)
    return NextResponse.json(
      { 
        success: false, 
        error: error?.message || 'Error al guardar los cambios',
        details: process.env.NODE_ENV === 'development' ? error?.stack : undefined
      },
      { status: 500 }
    )
  }
}
