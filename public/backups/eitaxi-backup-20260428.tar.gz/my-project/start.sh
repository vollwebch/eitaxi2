#!/bin/bash
export JWT_SECRET=eitaxi-super-secret-key-2024-change-in-production
export DATABASE_URL=file:/home/z/my-project/db/custom.db
cd /home/z/my-project/.next/standalone

while true; do
  node server.js &
  SERVER_PID=$!
  
  # Keepalive: ping every 10s
  while kill -0 $SERVER_PID 2>/dev/null; do
    sleep 10
    curl -s -o /dev/null http://localhost:3000/api/warmup 2>/dev/null
  done
  
  echo "Server died, restarting in 2s..."
  sleep 2
done
